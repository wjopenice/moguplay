-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 192.168.31.207
-- Port     : 3306
-- Database : db_newdata
-- 
-- Part : #1
-- Date : 2016-06-04 16:42:07
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `sys_action`
-- -----------------------------
DROP TABLE IF EXISTS `sys_action`;
CREATE TABLE `sys_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `sys_action`
-- -----------------------------
INSERT INTO `sys_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `sys_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `sys_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `sys_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `sys_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `sys_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `sys_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `sys_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `sys_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `sys_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `sys_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');
INSERT INTO `sys_action` VALUES ('12', 'asasasaas', '212121', '1212112', '', '', '2', '-1', '1464665704');

-- -----------------------------
-- Table structure for `sys_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `sys_action_log`;
CREATE TABLE `sys_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=609 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `sys_action_log`
-- -----------------------------
INSERT INTO `sys_action_log` VALUES ('1', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-19 15:09登录了后台', '1', '1463641766');
INSERT INTO `sys_action_log` VALUES ('2', '10', '1', '2130706433', 'Menu', '124', '操作url：/admin.php?s=/Menu/add.html', '1', '1463648320');
INSERT INTO `sys_action_log` VALUES ('3', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-19 21:27登录了后台', '1', '1463664464');
INSERT INTO `sys_action_log` VALUES ('4', '8', '1', '2130706433', 'attribute', '33', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('5', '8', '1', '2130706433', 'attribute', '34', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('6', '8', '1', '2130706433', 'attribute', '35', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('7', '8', '1', '2130706433', 'attribute', '36', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('8', '8', '1', '2130706433', 'attribute', '37', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('9', '8', '1', '2130706433', 'attribute', '38', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('10', '8', '1', '2130706433', 'attribute', '39', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('11', '8', '1', '2130706433', 'attribute', '40', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('12', '8', '1', '2130706433', 'attribute', '41', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('13', '8', '1', '2130706433', 'attribute', '42', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('14', '8', '1', '2130706433', 'attribute', '43', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('15', '8', '1', '2130706433', 'attribute', '44', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('16', '8', '1', '2130706433', 'attribute', '45', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('17', '8', '1', '2130706433', 'attribute', '46', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('18', '8', '1', '2130706433', 'attribute', '47', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('19', '8', '1', '2130706433', 'attribute', '48', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('20', '8', '1', '2130706433', 'attribute', '49', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('21', '8', '1', '2130706433', 'attribute', '50', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('22', '8', '1', '2130706433', 'attribute', '51', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('23', '8', '1', '2130706433', 'attribute', '52', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('24', '8', '1', '2130706433', 'attribute', '53', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('25', '8', '1', '2130706433', 'attribute', '54', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('26', '8', '1', '2130706433', 'attribute', '55', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('27', '8', '1', '2130706433', 'attribute', '56', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('28', '8', '1', '2130706433', 'attribute', '57', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('29', '8', '1', '2130706433', 'attribute', '58', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('30', '8', '1', '2130706433', 'attribute', '59', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('31', '8', '1', '2130706433', 'attribute', '60', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('32', '8', '1', '2130706433', 'attribute', '61', '操作url：/admin.php?s=/Model/generate.html', '1', '1463664513');
INSERT INTO `sys_action_log` VALUES ('33', '10', '1', '2130706433', 'Menu', '124', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463664551');
INSERT INTO `sys_action_log` VALUES ('34', '10', '1', '2130706433', 'Menu', '125', '操作url：/admin.php?s=/Menu/add.html', '1', '1463664624');
INSERT INTO `sys_action_log` VALUES ('35', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-19 21:30登录了后台', '1', '1463664652');
INSERT INTO `sys_action_log` VALUES ('36', '10', '1', '2130706433', 'Menu', '125', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463664684');
INSERT INTO `sys_action_log` VALUES ('37', '10', '1', '2130706433', 'Menu', '124', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463664694');
INSERT INTO `sys_action_log` VALUES ('38', '7', '1', '2130706433', 'model', '4', '操作url：/admin.php?s=/Model/update.html', '1', '1463664816');
INSERT INTO `sys_action_log` VALUES ('39', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-20 09:11登录了后台', '1', '1463706702');
INSERT INTO `sys_action_log` VALUES ('40', '7', '1', '2130706433', 'model', '4', '操作url：/admin.php?s=/Model/update.html', '1', '1463716424');
INSERT INTO `sys_action_log` VALUES ('41', '10', '1', '2130706433', 'Menu', '126', '操作url：/admin.php?s=/Menu/add.html', '1', '1463726199');
INSERT INTO `sys_action_log` VALUES ('42', '10', '1', '2130706433', 'Menu', '127', '操作url：/admin.php?s=/Menu/add.html', '1', '1463726219');
INSERT INTO `sys_action_log` VALUES ('43', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-23 09:30登录了后台', '1', '1463967055');
INSERT INTO `sys_action_log` VALUES ('44', '10', '1', '2130706433', 'Menu', '128', '操作url：/admin.php?s=/Menu/add.html', '1', '1463967714');
INSERT INTO `sys_action_log` VALUES ('45', '8', '1', '2130706433', 'attribute', '62', '操作url：/admin.php?s=/Model/generate.html', '1', '1463968087');
INSERT INTO `sys_action_log` VALUES ('46', '8', '1', '2130706433', 'attribute', '63', '操作url：/admin.php?s=/Model/generate.html', '1', '1463968087');
INSERT INTO `sys_action_log` VALUES ('47', '8', '1', '2130706433', 'attribute', '64', '操作url：/admin.php?s=/Model/generate.html', '1', '1463968087');
INSERT INTO `sys_action_log` VALUES ('48', '8', '1', '2130706433', 'attribute', '65', '操作url：/admin.php?s=/Model/generate.html', '1', '1463968087');
INSERT INTO `sys_action_log` VALUES ('49', '8', '1', '2130706433', 'attribute', '66', '操作url：/admin.php?s=/Model/generate.html', '1', '1463968087');
INSERT INTO `sys_action_log` VALUES ('50', '8', '1', '2130706433', 'attribute', '67', '操作url：/admin.php?s=/Model/generate.html', '1', '1463968087');
INSERT INTO `sys_action_log` VALUES ('51', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463969026');
INSERT INTO `sys_action_log` VALUES ('52', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463969037');
INSERT INTO `sys_action_log` VALUES ('53', '10', '1', '2130706433', 'Menu', '128', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463969095');
INSERT INTO `sys_action_log` VALUES ('54', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463969236');
INSERT INTO `sys_action_log` VALUES ('55', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463969769');
INSERT INTO `sys_action_log` VALUES ('56', '10', '1', '2130706433', 'Menu', '129', '操作url：/admin.php?s=/Menu/add.html', '1', '1463971267');
INSERT INTO `sys_action_log` VALUES ('57', '10', '1', '2130706433', 'Menu', '130', '操作url：/admin.php?s=/Menu/add.html', '1', '1463971291');
INSERT INTO `sys_action_log` VALUES ('58', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463974944');
INSERT INTO `sys_action_log` VALUES ('59', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463974974');
INSERT INTO `sys_action_log` VALUES ('60', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463975124');
INSERT INTO `sys_action_log` VALUES ('61', '7', '1', '2130706433', 'model', '5', '操作url：/admin.php?s=/Model/update.html', '1', '1463982517');
INSERT INTO `sys_action_log` VALUES ('62', '10', '1', '2130706433', 'Menu', '131', '操作url：/admin.php?s=/Menu/add.html', '1', '1463982625');
INSERT INTO `sys_action_log` VALUES ('63', '10', '1', '2130706433', 'Menu', '131', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463982858');
INSERT INTO `sys_action_log` VALUES ('64', '10', '1', '2130706433', 'Menu', '132', '操作url：/admin.php?s=/Menu/add.html', '1', '1463982880');
INSERT INTO `sys_action_log` VALUES ('65', '10', '1', '2130706433', 'Menu', '133', '操作url：/admin.php?s=/Menu/add.html', '1', '1463982902');
INSERT INTO `sys_action_log` VALUES ('66', '8', '1', '2130706433', 'attribute', '68', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('67', '8', '1', '2130706433', 'attribute', '69', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('68', '8', '1', '2130706433', 'attribute', '70', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('69', '8', '1', '2130706433', 'attribute', '71', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('70', '8', '1', '2130706433', 'attribute', '72', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('71', '8', '1', '2130706433', 'attribute', '73', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('72', '8', '1', '2130706433', 'attribute', '74', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('73', '8', '1', '2130706433', 'attribute', '75', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('74', '8', '1', '2130706433', 'attribute', '76', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('75', '8', '1', '2130706433', 'attribute', '77', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('76', '8', '1', '2130706433', 'attribute', '78', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('77', '8', '1', '2130706433', 'attribute', '79', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('78', '8', '1', '2130706433', 'attribute', '80', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('79', '8', '1', '2130706433', 'attribute', '81', '操作url：/admin.php?s=/Model/generate.html', '1', '1463982982');
INSERT INTO `sys_action_log` VALUES ('80', '7', '1', '2130706433', 'model', '6', '操作url：/admin.php?s=/Model/update.html', '1', '1463983103');
INSERT INTO `sys_action_log` VALUES ('81', '7', '1', '2130706433', 'model', '6', '操作url：/admin.php?s=/Model/update.html', '1', '1463983686');
INSERT INTO `sys_action_log` VALUES ('82', '7', '1', '2130706433', 'model', '6', '操作url：/admin.php?s=/Model/update.html', '1', '1463985396');
INSERT INTO `sys_action_log` VALUES ('83', '10', '1', '2130706433', 'Menu', '134', '操作url：/admin.php?s=/Menu/add.html', '1', '1463985645');
INSERT INTO `sys_action_log` VALUES ('84', '10', '1', '2130706433', 'Menu', '135', '操作url：/admin.php?s=/Menu/add.html', '1', '1463985684');
INSERT INTO `sys_action_log` VALUES ('85', '10', '1', '2130706433', 'Menu', '135', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463985815');
INSERT INTO `sys_action_log` VALUES ('86', '8', '1', '2130706433', 'attribute', '82', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('87', '8', '1', '2130706433', 'attribute', '83', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('88', '8', '1', '2130706433', 'attribute', '84', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('89', '8', '1', '2130706433', 'attribute', '85', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('90', '8', '1', '2130706433', 'attribute', '86', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('91', '8', '1', '2130706433', 'attribute', '87', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('92', '8', '1', '2130706433', 'attribute', '88', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('93', '8', '1', '2130706433', 'attribute', '89', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('94', '8', '1', '2130706433', 'attribute', '90', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('95', '8', '1', '2130706433', 'attribute', '91', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('96', '8', '1', '2130706433', 'attribute', '92', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('97', '8', '1', '2130706433', 'attribute', '93', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('98', '8', '1', '2130706433', 'attribute', '94', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('99', '8', '1', '2130706433', 'attribute', '95', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('100', '8', '1', '2130706433', 'attribute', '96', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('101', '8', '1', '2130706433', 'attribute', '97', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('102', '8', '1', '2130706433', 'attribute', '98', '操作url：/admin.php?s=/Model/generate.html', '1', '1463985936');
INSERT INTO `sys_action_log` VALUES ('103', '7', '1', '2130706433', 'model', '7', '操作url：/admin.php?s=/Model/update.html', '1', '1463986019');
INSERT INTO `sys_action_log` VALUES ('104', '10', '1', '2130706433', 'Menu', '136', '操作url：/admin.php?s=/Menu/add.html', '1', '1463986170');
INSERT INTO `sys_action_log` VALUES ('105', '10', '1', '2130706433', 'Menu', '137', '操作url：/admin.php?s=/Menu/add.html', '1', '1463986194');
INSERT INTO `sys_action_log` VALUES ('106', '10', '1', '2130706433', 'Menu', '137', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463986203');
INSERT INTO `sys_action_log` VALUES ('107', '10', '1', '2130706433', 'Menu', '135', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463987558');
INSERT INTO `sys_action_log` VALUES ('108', '8', '1', '2130706433', 'attribute', '99', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('109', '8', '1', '2130706433', 'attribute', '100', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('110', '8', '1', '2130706433', 'attribute', '101', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('111', '8', '1', '2130706433', 'attribute', '102', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('112', '8', '1', '2130706433', 'attribute', '103', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('113', '8', '1', '2130706433', 'attribute', '104', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('114', '8', '1', '2130706433', 'attribute', '105', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('115', '8', '1', '2130706433', 'attribute', '106', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('116', '8', '1', '2130706433', 'attribute', '107', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('117', '8', '1', '2130706433', 'attribute', '108', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('118', '8', '1', '2130706433', 'attribute', '109', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('119', '8', '1', '2130706433', 'attribute', '110', '操作url：/admin.php?s=/Model/generate.html', '1', '1463987676');
INSERT INTO `sys_action_log` VALUES ('120', '7', '1', '2130706433', 'model', '8', '操作url：/admin.php?s=/Model/update.html', '1', '1463987741');
INSERT INTO `sys_action_log` VALUES ('121', '7', '1', '2130706433', 'model', '8', '操作url：/admin.php?s=/Model/update.html', '1', '1463987918');
INSERT INTO `sys_action_log` VALUES ('122', '7', '1', '2130706433', 'model', '8', '操作url：/admin.php?s=/Model/update.html', '1', '1463987992');
INSERT INTO `sys_action_log` VALUES ('123', '10', '1', '2130706433', 'Menu', '138', '操作url：/admin.php?s=/Menu/add.html', '1', '1463988446');
INSERT INTO `sys_action_log` VALUES ('124', '8', '1', '2130706433', 'attribute', '111', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('125', '8', '1', '2130706433', 'attribute', '112', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('126', '8', '1', '2130706433', 'attribute', '113', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('127', '8', '1', '2130706433', 'attribute', '114', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('128', '8', '1', '2130706433', 'attribute', '115', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('129', '8', '1', '2130706433', 'attribute', '116', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('130', '8', '1', '2130706433', 'attribute', '117', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('131', '8', '1', '2130706433', 'attribute', '118', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('132', '8', '1', '2130706433', 'attribute', '119', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('133', '8', '1', '2130706433', 'attribute', '120', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('134', '8', '1', '2130706433', 'attribute', '121', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('135', '8', '1', '2130706433', 'attribute', '122', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('136', '8', '1', '2130706433', 'attribute', '123', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('137', '8', '1', '2130706433', 'attribute', '124', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('138', '8', '1', '2130706433', 'attribute', '125', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('139', '8', '1', '2130706433', 'attribute', '126', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('140', '8', '1', '2130706433', 'attribute', '127', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('141', '8', '1', '2130706433', 'attribute', '128', '操作url：/admin.php?s=/Model/generate.html', '1', '1463989240');
INSERT INTO `sys_action_log` VALUES ('142', '7', '1', '2130706433', 'model', '9', '操作url：/admin.php?s=/Model/update.html', '1', '1463989273');
INSERT INTO `sys_action_log` VALUES ('143', '10', '1', '2130706433', 'Menu', '139', '操作url：/admin.php?s=/Menu/add.html', '1', '1463989404');
INSERT INTO `sys_action_log` VALUES ('144', '10', '1', '2130706433', 'Menu', '140', '操作url：/admin.php?s=/Menu/add.html', '1', '1463989455');
INSERT INTO `sys_action_log` VALUES ('145', '10', '1', '2130706433', 'Menu', '141', '操作url：/admin.php?s=/Menu/add.html', '1', '1463989473');
INSERT INTO `sys_action_log` VALUES ('146', '10', '1', '2130706433', 'Menu', '142', '操作url：/admin.php?s=/Menu/add.html', '1', '1463990417');
INSERT INTO `sys_action_log` VALUES ('147', '10', '1', '2130706433', 'Menu', '143', '操作url：/admin.php?s=/Menu/add.html', '1', '1463990484');
INSERT INTO `sys_action_log` VALUES ('148', '10', '1', '2130706433', 'Menu', '144', '操作url：/admin.php?s=/Menu/add.html', '1', '1463990724');
INSERT INTO `sys_action_log` VALUES ('149', '10', '1', '2130706433', 'Menu', '145', '操作url：/admin.php?s=/Menu/add.html', '1', '1463991689');
INSERT INTO `sys_action_log` VALUES ('150', '10', '1', '2130706433', 'Menu', '145', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463991716');
INSERT INTO `sys_action_log` VALUES ('151', '10', '1', '2130706433', 'Menu', '146', '操作url：/admin.php?s=/Menu/add.html', '1', '1463991746');
INSERT INTO `sys_action_log` VALUES ('152', '10', '1', '2130706433', 'Menu', '146', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463991757');
INSERT INTO `sys_action_log` VALUES ('153', '10', '1', '2130706433', 'Menu', '147', '操作url：/admin.php?s=/Menu/add.html', '1', '1463991784');
INSERT INTO `sys_action_log` VALUES ('154', '10', '1', '2130706433', 'Menu', '148', '操作url：/admin.php?s=/Menu/add.html', '1', '1463991810');
INSERT INTO `sys_action_log` VALUES ('155', '10', '1', '2130706433', 'Menu', '148', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463991821');
INSERT INTO `sys_action_log` VALUES ('156', '10', '1', '2130706433', 'Menu', '149', '操作url：/admin.php?s=/Menu/add.html', '1', '1463991848');
INSERT INTO `sys_action_log` VALUES ('157', '10', '1', '2130706433', 'Menu', '150', '操作url：/admin.php?s=/Menu/add.html', '1', '1463991869');
INSERT INTO `sys_action_log` VALUES ('158', '10', '1', '2130706433', 'Menu', '142', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463996779');
INSERT INTO `sys_action_log` VALUES ('159', '10', '1', '2130706433', 'Menu', '143', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463996807');
INSERT INTO `sys_action_log` VALUES ('160', '8', '1', '2130706433', 'attribute', '129', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('161', '8', '1', '2130706433', 'attribute', '130', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('162', '8', '1', '2130706433', 'attribute', '131', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('163', '8', '1', '2130706433', 'attribute', '132', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('164', '8', '1', '2130706433', 'attribute', '133', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('165', '8', '1', '2130706433', 'attribute', '134', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('166', '8', '1', '2130706433', 'attribute', '135', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('167', '8', '1', '2130706433', 'attribute', '136', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('168', '8', '1', '2130706433', 'attribute', '137', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('169', '8', '1', '2130706433', 'attribute', '138', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('170', '8', '1', '2130706433', 'attribute', '139', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997570');
INSERT INTO `sys_action_log` VALUES ('171', '7', '1', '2130706433', 'model', '10', '操作url：/admin.php?s=/Model/update.html', '1', '1463997589');
INSERT INTO `sys_action_log` VALUES ('172', '8', '1', '2130706433', 'attribute', '140', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('173', '8', '1', '2130706433', 'attribute', '141', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('174', '8', '1', '2130706433', 'attribute', '142', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('175', '8', '1', '2130706433', 'attribute', '143', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('176', '8', '1', '2130706433', 'attribute', '144', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('177', '8', '1', '2130706433', 'attribute', '145', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('178', '8', '1', '2130706433', 'attribute', '146', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('179', '8', '1', '2130706433', 'attribute', '147', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('180', '8', '1', '2130706433', 'attribute', '148', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('181', '8', '1', '2130706433', 'attribute', '149', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('182', '8', '1', '2130706433', 'attribute', '150', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('183', '8', '1', '2130706433', 'attribute', '151', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('184', '8', '1', '2130706433', 'attribute', '152', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('185', '8', '1', '2130706433', 'attribute', '153', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('186', '8', '1', '2130706433', 'attribute', '154', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('187', '8', '1', '2130706433', 'attribute', '155', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('188', '8', '1', '2130706433', 'attribute', '156', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('189', '8', '1', '2130706433', 'attribute', '157', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('190', '8', '1', '2130706433', 'attribute', '158', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997820');
INSERT INTO `sys_action_log` VALUES ('191', '7', '1', '2130706433', 'model', '11', '操作url：/admin.php?s=/Model/update.html', '1', '1463997834');
INSERT INTO `sys_action_log` VALUES ('192', '8', '1', '2130706433', 'attribute', '159', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('193', '8', '1', '2130706433', 'attribute', '160', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('194', '8', '1', '2130706433', 'attribute', '161', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('195', '8', '1', '2130706433', 'attribute', '162', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('196', '8', '1', '2130706433', 'attribute', '163', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('197', '8', '1', '2130706433', 'attribute', '164', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('198', '8', '1', '2130706433', 'attribute', '165', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('199', '8', '1', '2130706433', 'attribute', '166', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('200', '8', '1', '2130706433', 'attribute', '167', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('201', '8', '1', '2130706433', 'attribute', '168', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('202', '8', '1', '2130706433', 'attribute', '169', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('203', '8', '1', '2130706433', 'attribute', '170', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('204', '8', '1', '2130706433', 'attribute', '171', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('205', '8', '1', '2130706433', 'attribute', '172', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997856');
INSERT INTO `sys_action_log` VALUES ('206', '8', '1', '2130706433', 'attribute', '173', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('207', '8', '1', '2130706433', 'attribute', '174', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('208', '8', '1', '2130706433', 'attribute', '175', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('209', '8', '1', '2130706433', 'attribute', '176', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('210', '8', '1', '2130706433', 'attribute', '177', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('211', '8', '1', '2130706433', 'attribute', '178', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('212', '8', '1', '2130706433', 'attribute', '179', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('213', '8', '1', '2130706433', 'attribute', '180', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('214', '8', '1', '2130706433', 'attribute', '181', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('215', '8', '1', '2130706433', 'attribute', '182', '操作url：/admin.php?s=/Model/generate.html', '1', '1463997904');
INSERT INTO `sys_action_log` VALUES ('216', '7', '1', '2130706433', 'model', '13', '操作url：/admin.php?s=/Model/update.html', '1', '1463997941');
INSERT INTO `sys_action_log` VALUES ('217', '7', '1', '2130706433', 'model', '12', '操作url：/admin.php?s=/Model/update.html', '1', '1463997966');
INSERT INTO `sys_action_log` VALUES ('218', '10', '1', '2130706433', 'Menu', '143', '操作url：/admin.php?s=/Menu/edit.html', '1', '1463998525');
INSERT INTO `sys_action_log` VALUES ('219', '10', '1', '2130706433', 'Menu', '2', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464003565');
INSERT INTO `sys_action_log` VALUES ('220', '10', '1', '2130706433', 'Menu', '17', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464010491');
INSERT INTO `sys_action_log` VALUES ('221', '10', '1', '2130706433', 'Menu', '19', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464010500');
INSERT INTO `sys_action_log` VALUES ('222', '10', '1', '2130706433', 'Menu', '27', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464010510');
INSERT INTO `sys_action_log` VALUES ('223', '10', '1', '2130706433', 'Menu', '106', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464010517');
INSERT INTO `sys_action_log` VALUES ('224', '10', '1', '2130706433', 'Menu', '151', '操作url：/admin.php?s=/Menu/add.html', '1', '1464010554');
INSERT INTO `sys_action_log` VALUES ('225', '10', '1', '2130706433', 'Menu', '152', '操作url：/admin.php?s=/Menu/add.html', '1', '1464010571');
INSERT INTO `sys_action_log` VALUES ('226', '10', '1', '2130706433', 'Menu', '153', '操作url：/admin.php?s=/Menu/add.html', '1', '1464010600');
INSERT INTO `sys_action_log` VALUES ('227', '10', '1', '2130706433', 'Menu', '154', '操作url：/admin.php?s=/Menu/add.html', '1', '1464010627');
INSERT INTO `sys_action_log` VALUES ('228', '10', '1', '2130706433', 'Menu', '155', '操作url：/admin.php?s=/Menu/add.html', '1', '1464010648');
INSERT INTO `sys_action_log` VALUES ('229', '10', '1', '2130706433', 'Menu', '156', '操作url：/admin.php?s=/Menu/add.html', '1', '1464010666');
INSERT INTO `sys_action_log` VALUES ('230', '10', '1', '2130706433', 'Menu', '151', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464011417');
INSERT INTO `sys_action_log` VALUES ('231', '10', '1', '2130706433', 'Menu', '152', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464011440');
INSERT INTO `sys_action_log` VALUES ('232', '8', '1', '2130706433', 'attribute', '183', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('233', '8', '1', '2130706433', 'attribute', '184', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('234', '8', '1', '2130706433', 'attribute', '185', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('235', '8', '1', '2130706433', 'attribute', '186', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('236', '8', '1', '2130706433', 'attribute', '187', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('237', '8', '1', '2130706433', 'attribute', '188', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('238', '8', '1', '2130706433', 'attribute', '189', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('239', '8', '1', '2130706433', 'attribute', '190', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('240', '8', '1', '2130706433', 'attribute', '191', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('241', '8', '1', '2130706433', 'attribute', '192', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('242', '8', '1', '2130706433', 'attribute', '193', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('243', '8', '1', '2130706433', 'attribute', '194', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('244', '8', '1', '2130706433', 'attribute', '195', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('245', '8', '1', '2130706433', 'attribute', '196', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('246', '8', '1', '2130706433', 'attribute', '197', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('247', '8', '1', '2130706433', 'attribute', '198', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('248', '8', '1', '2130706433', 'attribute', '199', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('249', '8', '1', '2130706433', 'attribute', '200', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('250', '8', '1', '2130706433', 'attribute', '201', '操作url：/admin.php?s=/Model/generate.html', '1', '1464012355');
INSERT INTO `sys_action_log` VALUES ('251', '10', '1', '2130706433', 'Menu', '153', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464012965');
INSERT INTO `sys_action_log` VALUES ('252', '10', '1', '2130706433', 'Menu', '153', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464013024');
INSERT INTO `sys_action_log` VALUES ('253', '10', '1', '2130706433', 'Menu', '154', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464013080');
INSERT INTO `sys_action_log` VALUES ('254', '10', '1', '2130706433', 'Menu', '155', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464013107');
INSERT INTO `sys_action_log` VALUES ('255', '10', '1', '2130706433', 'Menu', '156', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464013231');
INSERT INTO `sys_action_log` VALUES ('256', '10', '1', '2130706433', 'Menu', '155', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464013647');
INSERT INTO `sys_action_log` VALUES ('257', '10', '1', '2130706433', 'Menu', '156', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464013656');
INSERT INTO `sys_action_log` VALUES ('258', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-24 07:58登录了后台', '1', '1464047913');
INSERT INTO `sys_action_log` VALUES ('259', '10', '1', '2130706433', 'Menu', '157', '操作url：/admin.php?s=/Menu/add.html', '1', '1464049188');
INSERT INTO `sys_action_log` VALUES ('260', '10', '1', '2130706433', 'Menu', '158', '操作url：/admin.php?s=/Menu/add.html', '1', '1464049284');
INSERT INTO `sys_action_log` VALUES ('261', '10', '1', '2130706433', 'Menu', '159', '操作url：/admin.php?s=/Menu/add.html', '1', '1464049393');
INSERT INTO `sys_action_log` VALUES ('262', '10', '1', '2130706433', 'Menu', '160', '操作url：/admin.php?s=/Menu/add.html', '1', '1464049826');
INSERT INTO `sys_action_log` VALUES ('263', '10', '1', '2130706433', 'Menu', '161', '操作url：/admin.php?s=/Menu/add.html', '1', '1464050218');
INSERT INTO `sys_action_log` VALUES ('264', '10', '1', '2130706433', 'Menu', '162', '操作url：/admin.php?s=/Menu/add.html', '1', '1464050278');
INSERT INTO `sys_action_log` VALUES ('265', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-24 10:06登录了后台', '1', '1464055570');
INSERT INTO `sys_action_log` VALUES ('266', '6', '1', '2130706433', 'config', '39', '操作url：/admin.php?s=/Config/edit.html', '1', '1464057800');
INSERT INTO `sys_action_log` VALUES ('267', '10', '1', '2130706433', 'Menu', '158', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464060433');
INSERT INTO `sys_action_log` VALUES ('268', '10', '1', '2130706433', 'Menu', '161', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464060488');
INSERT INTO `sys_action_log` VALUES ('269', '10', '1', '2130706433', 'Menu', '162', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464060500');
INSERT INTO `sys_action_log` VALUES ('270', '10', '1', '2130706433', 'Menu', '157', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464060542');
INSERT INTO `sys_action_log` VALUES ('271', '10', '1', '2130706433', 'Menu', '157', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464068359');
INSERT INTO `sys_action_log` VALUES ('272', '10', '1', '2130706433', 'Menu', '158', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464068391');
INSERT INTO `sys_action_log` VALUES ('273', '10', '1', '2130706433', 'Menu', '162', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464068404');
INSERT INTO `sys_action_log` VALUES ('274', '10', '1', '2130706433', 'Menu', '161', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464068413');
INSERT INTO `sys_action_log` VALUES ('275', '6', '1', '2130706433', 'config', '38', '操作url：/admin.php?s=/Config/edit.html', '1', '1464071718');
INSERT INTO `sys_action_log` VALUES ('276', '6', '1', '2130706433', 'config', '40', '操作url：/admin.php?s=/Config/edit.html', '1', '1464073572');
INSERT INTO `sys_action_log` VALUES ('277', '6', '1', '2130706433', 'config', '40', '操作url：/admin.php?s=/Config/edit.html', '1', '1464073632');
INSERT INTO `sys_action_log` VALUES ('278', '6', '1', '2130706433', 'config', '41', '操作url：/admin.php?s=/Config/edit.html', '1', '1464073677');
INSERT INTO `sys_action_log` VALUES ('279', '6', '1', '2130706433', 'config', '40', '操作url：/admin.php?s=/Config/edit.html', '1', '1464073714');
INSERT INTO `sys_action_log` VALUES ('280', '6', '1', '2130706433', 'config', '41', '操作url：/admin.php?s=/Config/edit.html', '1', '1464073728');
INSERT INTO `sys_action_log` VALUES ('281', '6', '1', '2130706433', 'config', '42', '操作url：/admin.php?s=/Config/edit.html', '1', '1464074463');
INSERT INTO `sys_action_log` VALUES ('282', '6', '1', '2130706433', 'config', '46', '操作url：/admin.php?s=/Config/edit.html', '1', '1464075647');
INSERT INTO `sys_action_log` VALUES ('283', '6', '1', '2130706433', 'config', '47', '操作url：/admin.php?s=/Config/edit.html', '1', '1464075750');
INSERT INTO `sys_action_log` VALUES ('284', '6', '1', '2130706433', 'config', '39', '操作url：/admin.php?s=/Config/edit.html', '1', '1464075821');
INSERT INTO `sys_action_log` VALUES ('285', '10', '1', '2130706433', 'Menu', '163', '操作url：/admin.php?s=/Menu/add.html', '1', '1464076838');
INSERT INTO `sys_action_log` VALUES ('286', '10', '1', '2130706433', 'Menu', '159', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464083371');
INSERT INTO `sys_action_log` VALUES ('287', '10', '1', '2130706433', 'Menu', '163', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464083386');
INSERT INTO `sys_action_log` VALUES ('288', '8', '1', '2130706433', 'attribute', '202', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('289', '8', '1', '2130706433', 'attribute', '203', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('290', '8', '1', '2130706433', 'attribute', '204', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('291', '8', '1', '2130706433', 'attribute', '205', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('292', '8', '1', '2130706433', 'attribute', '206', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('293', '8', '1', '2130706433', 'attribute', '207', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('294', '8', '1', '2130706433', 'attribute', '208', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('295', '8', '1', '2130706433', 'attribute', '209', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('296', '8', '1', '2130706433', 'attribute', '210', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('297', '8', '1', '2130706433', 'attribute', '211', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('298', '8', '1', '2130706433', 'attribute', '212', '操作url：/admin.php?s=/Model/generate.html', '1', '1464083427');
INSERT INTO `sys_action_log` VALUES ('299', '7', '1', '2130706433', 'model', '15', '操作url：/admin.php?s=/Model/update.html', '1', '1464083443');
INSERT INTO `sys_action_log` VALUES ('300', '8', '1', '2130706433', 'attribute', '213', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('301', '8', '1', '2130706433', 'attribute', '214', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('302', '8', '1', '2130706433', 'attribute', '215', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('303', '8', '1', '2130706433', 'attribute', '216', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('304', '8', '1', '2130706433', 'attribute', '217', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('305', '8', '1', '2130706433', 'attribute', '218', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('306', '8', '1', '2130706433', 'attribute', '219', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('307', '8', '1', '2130706433', 'attribute', '220', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('308', '8', '1', '2130706433', 'attribute', '221', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('309', '8', '1', '2130706433', 'attribute', '222', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('310', '8', '1', '2130706433', 'attribute', '223', '操作url：/admin.php?s=/Model/generate.html', '1', '1464084894');
INSERT INTO `sys_action_log` VALUES ('311', '7', '1', '2130706433', 'model', '16', '操作url：/admin.php?s=/Model/update.html', '1', '1464084907');
INSERT INTO `sys_action_log` VALUES ('312', '7', '1', '2130706433', 'model', '16', '操作url：/admin.php?s=/Model/update.html', '1', '1464084920');
INSERT INTO `sys_action_log` VALUES ('313', '10', '1', '2130706433', 'Menu', '163', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464084952');
INSERT INTO `sys_action_log` VALUES ('314', '10', '1', '2130706433', 'Menu', '159', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464084962');
INSERT INTO `sys_action_log` VALUES ('315', '7', '1', '2130706433', 'model', '16', '操作url：/admin.php?s=/Model/update.html', '1', '1464086978');
INSERT INTO `sys_action_log` VALUES ('316', '7', '1', '2130706433', 'model', '16', '操作url：/admin.php?s=/Model/update.html', '1', '1464087047');
INSERT INTO `sys_action_log` VALUES ('317', '10', '1', '2130706433', 'Menu', '164', '操作url：/admin.php?s=/Menu/add.html', '1', '1464087801');
INSERT INTO `sys_action_log` VALUES ('318', '10', '1', '2130706433', 'Menu', '164', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464093594');
INSERT INTO `sys_action_log` VALUES ('319', '10', '1', '2130706433', 'Menu', '159', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464093926');
INSERT INTO `sys_action_log` VALUES ('320', '10', '1', '2130706433', 'Menu', '163', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464094173');
INSERT INTO `sys_action_log` VALUES ('321', '10', '1', '2130706433', 'Menu', '165', '操作url：/admin.php?s=/Menu/add.html', '1', '1464094981');
INSERT INTO `sys_action_log` VALUES ('322', '10', '1', '2130706433', 'Menu', '164', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464095276');
INSERT INTO `sys_action_log` VALUES ('323', '10', '1', '2130706433', 'Menu', '166', '操作url：/admin.php?s=/Menu/add.html', '1', '1464095308');
INSERT INTO `sys_action_log` VALUES ('324', '10', '1', '2130706433', 'Menu', '167', '操作url：/admin.php?s=/Menu/add.html', '1', '1464095348');
INSERT INTO `sys_action_log` VALUES ('325', '10', '1', '2130706433', 'Menu', '168', '操作url：/admin.php?s=/Menu/add.html', '1', '1464095374');
INSERT INTO `sys_action_log` VALUES ('326', '10', '1', '2130706433', 'Menu', '169', '操作url：/admin.php?s=/Menu/add.html', '1', '1464095444');
INSERT INTO `sys_action_log` VALUES ('327', '10', '1', '2130706433', 'Menu', '170', '操作url：/admin.php?s=/Menu/add.html', '1', '1464095490');
INSERT INTO `sys_action_log` VALUES ('328', '10', '1', '2130706433', 'Menu', '171', '操作url：/admin.php?s=/Menu/add.html', '1', '1464095515');
INSERT INTO `sys_action_log` VALUES ('329', '10', '1', '2130706433', 'Menu', '172', '操作url：/admin.php?s=/Menu/add.html', '1', '1464099002');
INSERT INTO `sys_action_log` VALUES ('330', '7', '1', '2130706433', 'model', '15', '操作url：/admin.php?s=/Model/update.html', '1', '1464099717');
INSERT INTO `sys_action_log` VALUES ('331', '7', '1', '2130706433', 'model', '15', '操作url：/admin.php?s=/Model/update.html', '1', '1464099752');
INSERT INTO `sys_action_log` VALUES ('332', '10', '1', '2130706433', 'Menu', '173', '操作url：/admin.php?s=/Menu/add.html', '1', '1464102539');
INSERT INTO `sys_action_log` VALUES ('333', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-25 08:05登录了后台', '1', '1464134752');
INSERT INTO `sys_action_log` VALUES ('334', '6', '1', '2130706433', 'config', '9', '操作url：/admin.php?s=/Config/edit.html', '1', '1464137919');
INSERT INTO `sys_action_log` VALUES ('335', '6', '1', '2130706433', 'config', '56', '操作url：/admin.php?s=/Config/edit.html', '1', '1464138034');
INSERT INTO `sys_action_log` VALUES ('336', '10', '1', '2130706433', 'Menu', '174', '操作url：/admin.php?s=/Menu/add.html', '1', '1464145008');
INSERT INTO `sys_action_log` VALUES ('337', '10', '1', '2130706433', 'Menu', '175', '操作url：/admin.php?s=/Menu/add.html', '1', '1464145028');
INSERT INTO `sys_action_log` VALUES ('338', '10', '1', '2130706433', 'Menu', '175', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464146403');
INSERT INTO `sys_action_log` VALUES ('339', '10', '1', '2130706433', 'Menu', '175', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464146429');
INSERT INTO `sys_action_log` VALUES ('340', '10', '1', '2130706433', 'Menu', '174', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464146462');
INSERT INTO `sys_action_log` VALUES ('341', '10', '1', '2130706433', 'Menu', '176', '操作url：/admin.php?s=/Menu/add.html', '1', '1464157021');
INSERT INTO `sys_action_log` VALUES ('342', '6', '1', '2130706433', 'config', '61', '操作url：/admin.php?s=/Config/edit.html', '1', '1464157394');
INSERT INTO `sys_action_log` VALUES ('343', '6', '1', '2130706433', 'config', '59', '操作url：/admin.php?s=/Config/edit.html', '1', '1464157417');
INSERT INTO `sys_action_log` VALUES ('344', '6', '1', '2130706433', 'config', '60', '操作url：/admin.php?s=/Config/edit.html', '1', '1464157438');
INSERT INTO `sys_action_log` VALUES ('345', '6', '1', '2130706433', 'config', '62', '操作url：/admin.php?s=/Config/edit.html', '1', '1464157691');
INSERT INTO `sys_action_log` VALUES ('346', '10', '1', '2130706433', 'Menu', '177', '操作url：/admin.php?s=/Menu/add.html', '1', '1464158306');
INSERT INTO `sys_action_log` VALUES ('347', '10', '1', '2130706433', 'Menu', '177', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464158349');
INSERT INTO `sys_action_log` VALUES ('348', '10', '1', '2130706433', 'Menu', '178', '操作url：/admin.php?s=/Menu/add.html', '1', '1464158374');
INSERT INTO `sys_action_log` VALUES ('349', '10', '1', '2130706433', 'Menu', '178', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464158386');
INSERT INTO `sys_action_log` VALUES ('350', '10', '1', '2130706433', 'Menu', '179', '操作url：/admin.php?s=/Menu/add.html', '1', '1464158414');
INSERT INTO `sys_action_log` VALUES ('351', '10', '1', '2130706433', 'Menu', '179', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464158517');
INSERT INTO `sys_action_log` VALUES ('352', '10', '1', '2130706433', 'Menu', '180', '操作url：/admin.php?s=/Menu/add.html', '1', '1464158569');
INSERT INTO `sys_action_log` VALUES ('353', '10', '1', '2130706433', 'Menu', '181', '操作url：/admin.php?s=/Menu/add.html', '1', '1464159081');
INSERT INTO `sys_action_log` VALUES ('354', '10', '1', '2130706433', 'Menu', '181', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464159096');
INSERT INTO `sys_action_log` VALUES ('355', '10', '1', '2130706433', 'Menu', '180', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464159107');
INSERT INTO `sys_action_log` VALUES ('356', '10', '1', '2130706433', 'Menu', '177', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464162284');
INSERT INTO `sys_action_log` VALUES ('357', '10', '1', '2130706433', 'Menu', '178', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464162304');
INSERT INTO `sys_action_log` VALUES ('358', '10', '1', '2130706433', 'Menu', '179', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464162318');
INSERT INTO `sys_action_log` VALUES ('359', '10', '1', '2130706433', 'Menu', '181', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464162330');
INSERT INTO `sys_action_log` VALUES ('360', '10', '1', '2130706433', 'Menu', '180', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464162348');
INSERT INTO `sys_action_log` VALUES ('361', '10', '1', '2130706433', 'Menu', '182', '操作url：/admin.php?s=/Menu/add.html', '1', '1464180925');
INSERT INTO `sys_action_log` VALUES ('362', '10', '1', '2130706433', 'Menu', '183', '操作url：/admin.php?s=/Menu/add.html', '1', '1464180939');
INSERT INTO `sys_action_log` VALUES ('363', '10', '1', '2130706433', 'Menu', '182', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464180948');
INSERT INTO `sys_action_log` VALUES ('364', '10', '1', '2130706433', 'Menu', '183', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464180957');
INSERT INTO `sys_action_log` VALUES ('365', '10', '1', '2130706433', 'Menu', '184', '操作url：/admin.php?s=/Menu/add.html', '1', '1464180988');
INSERT INTO `sys_action_log` VALUES ('366', '10', '1', '2130706433', 'Menu', '184', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464180995');
INSERT INTO `sys_action_log` VALUES ('367', '10', '1', '2130706433', 'Menu', '185', '操作url：/admin.php?s=/Menu/add.html', '1', '1464181015');
INSERT INTO `sys_action_log` VALUES ('368', '10', '1', '2130706433', 'Menu', '186', '操作url：/admin.php?s=/Menu/add.html', '1', '1464181047');
INSERT INTO `sys_action_log` VALUES ('369', '10', '1', '2130706433', 'Menu', '187', '操作url：/admin.php?s=/Menu/add.html', '1', '1464181077');
INSERT INTO `sys_action_log` VALUES ('370', '10', '1', '2130706433', 'Menu', '188', '操作url：/admin.php?s=/Menu/add.html', '1', '1464181104');
INSERT INTO `sys_action_log` VALUES ('371', '10', '1', '2130706433', 'Menu', '182', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464181873');
INSERT INTO `sys_action_log` VALUES ('372', '10', '1', '2130706433', 'Menu', '160', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464181899');
INSERT INTO `sys_action_log` VALUES ('373', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-26 08:26登录了后台', '1', '1464222389');
INSERT INTO `sys_action_log` VALUES ('374', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464232653');
INSERT INTO `sys_action_log` VALUES ('375', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464232688');
INSERT INTO `sys_action_log` VALUES ('376', '8', '1', '2130706433', 'attribute', '224', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('377', '8', '1', '2130706433', 'attribute', '225', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('378', '8', '1', '2130706433', 'attribute', '226', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('379', '8', '1', '2130706433', 'attribute', '227', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('380', '8', '1', '2130706433', 'attribute', '228', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('381', '8', '1', '2130706433', 'attribute', '229', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('382', '8', '1', '2130706433', 'attribute', '230', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('383', '8', '1', '2130706433', 'attribute', '231', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('384', '8', '1', '2130706433', 'attribute', '232', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('385', '8', '1', '2130706433', 'attribute', '233', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('386', '8', '1', '2130706433', 'attribute', '234', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('387', '8', '1', '2130706433', 'attribute', '235', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('388', '8', '1', '2130706433', 'attribute', '236', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233084');
INSERT INTO `sys_action_log` VALUES ('389', '7', '1', '2130706433', 'model', '17', '操作url：/admin.php?s=/Model/update.html', '1', '1464233284');
INSERT INTO `sys_action_log` VALUES ('390', '8', '1', '2130706433', 'attribute', '237', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('391', '8', '1', '2130706433', 'attribute', '238', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('392', '8', '1', '2130706433', 'attribute', '239', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('393', '8', '1', '2130706433', 'attribute', '240', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('394', '8', '1', '2130706433', 'attribute', '241', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('395', '8', '1', '2130706433', 'attribute', '242', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('396', '8', '1', '2130706433', 'attribute', '243', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('397', '8', '1', '2130706433', 'attribute', '244', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('398', '8', '1', '2130706433', 'attribute', '245', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('399', '8', '1', '2130706433', 'attribute', '246', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('400', '8', '1', '2130706433', 'attribute', '247', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('401', '8', '1', '2130706433', 'attribute', '248', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('402', '8', '1', '2130706433', 'attribute', '249', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('403', '8', '1', '2130706433', 'attribute', '250', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('404', '8', '1', '2130706433', 'attribute', '251', '操作url：/admin.php?s=/Model/generate.html', '1', '1464233863');
INSERT INTO `sys_action_log` VALUES ('405', '7', '1', '2130706433', 'model', '18', '操作url：/admin.php?s=/Model/update.html', '1', '1464233961');
INSERT INTO `sys_action_log` VALUES ('406', '8', '1', '2130706433', 'attribute', '252', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('407', '8', '1', '2130706433', 'attribute', '253', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('408', '8', '1', '2130706433', 'attribute', '254', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('409', '8', '1', '2130706433', 'attribute', '255', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('410', '8', '1', '2130706433', 'attribute', '256', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('411', '8', '1', '2130706433', 'attribute', '257', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('412', '8', '1', '2130706433', 'attribute', '258', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('413', '8', '1', '2130706433', 'attribute', '259', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('414', '8', '1', '2130706433', 'attribute', '260', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('415', '8', '1', '2130706433', 'attribute', '261', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('416', '8', '1', '2130706433', 'attribute', '262', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('417', '8', '1', '2130706433', 'attribute', '263', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('418', '8', '1', '2130706433', 'attribute', '264', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('419', '8', '1', '2130706433', 'attribute', '265', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('420', '8', '1', '2130706433', 'attribute', '266', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('421', '8', '1', '2130706433', 'attribute', '267', '操作url：/admin.php?s=/Model/generate.html', '1', '1464234376');
INSERT INTO `sys_action_log` VALUES ('422', '7', '1', '2130706433', 'model', '19', '操作url：/admin.php?s=/Model/update.html', '1', '1464234501');
INSERT INTO `sys_action_log` VALUES ('423', '7', '1', '2130706433', 'model', '19', '操作url：/admin.php?s=/Model/update.html', '1', '1464234528');
INSERT INTO `sys_action_log` VALUES ('424', '7', '1', '2130706433', 'model', '19', '操作url：/admin.php?s=/Model/update.html', '1', '1464234739');
INSERT INTO `sys_action_log` VALUES ('425', '8', '1', '2130706433', 'attribute', '268', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('426', '8', '1', '2130706433', 'attribute', '269', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('427', '8', '1', '2130706433', 'attribute', '270', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('428', '8', '1', '2130706433', 'attribute', '271', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('429', '8', '1', '2130706433', 'attribute', '272', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('430', '8', '1', '2130706433', 'attribute', '273', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('431', '8', '1', '2130706433', 'attribute', '274', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('432', '8', '1', '2130706433', 'attribute', '275', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('433', '8', '1', '2130706433', 'attribute', '276', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('434', '8', '1', '2130706433', 'attribute', '277', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('435', '8', '1', '2130706433', 'attribute', '278', '操作url：/admin.php?s=/Model/generate.html', '1', '1464235301');
INSERT INTO `sys_action_log` VALUES ('436', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464235436');
INSERT INTO `sys_action_log` VALUES ('437', '10', '1', '2130706433', 'Menu', '189', '操作url：/admin.php?s=/Menu/add.html', '1', '1464235603');
INSERT INTO `sys_action_log` VALUES ('438', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464235654');
INSERT INTO `sys_action_log` VALUES ('439', '10', '1', '2130706433', 'Menu', '190', '操作url：/admin.php?s=/Menu/add.html', '1', '1464241747');
INSERT INTO `sys_action_log` VALUES ('440', '10', '1', '2130706433', 'Menu', '191', '操作url：/admin.php?s=/Menu/add.html', '1', '1464241766');
INSERT INTO `sys_action_log` VALUES ('441', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-26 17:15登录了后台', '1', '1464254112');
INSERT INTO `sys_action_log` VALUES ('442', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-27 08:25登录了后台', '1', '1464308750');
INSERT INTO `sys_action_log` VALUES ('443', '7', '1', '2130706433', 'model', '11', '操作url：/admin.php?s=/Model/update.html', '1', '1464310953');
INSERT INTO `sys_action_log` VALUES ('444', '10', '1', '2130706433', 'Menu', '192', '操作url：/admin.php?s=/Menu/add.html', '1', '1464311548');
INSERT INTO `sys_action_log` VALUES ('445', '7', '1', '2130706433', 'model', '10', '操作url：/admin.php?s=/Model/update.html', '1', '1464332299');
INSERT INTO `sys_action_log` VALUES ('446', '7', '1', '2130706433', 'model', '10', '操作url：/admin.php?s=/Model/update.html', '1', '1464332332');
INSERT INTO `sys_action_log` VALUES ('447', '10', '1', '2130706433', 'Menu', '144', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464333923');
INSERT INTO `sys_action_log` VALUES ('448', '7', '1', '2130706433', 'model', '11', '操作url：/admin.php?s=/Model/update.html', '1', '1464334190');
INSERT INTO `sys_action_log` VALUES ('449', '7', '1', '2130706433', 'model', '11', '操作url：/admin.php?s=/Model/update.html', '1', '1464334834');
INSERT INTO `sys_action_log` VALUES ('450', '7', '1', '2130706433', 'model', '11', '操作url：/admin.php?s=/Model/update.html', '1', '1464335010');
INSERT INTO `sys_action_log` VALUES ('451', '7', '1', '2130706433', 'model', '11', '操作url：/admin.php?s=/Model/update.html', '1', '1464335255');
INSERT INTO `sys_action_log` VALUES ('452', '10', '1', '2130706433', 'Menu', '145', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464336340');
INSERT INTO `sys_action_log` VALUES ('453', '8', '1', '2130706433', 'attribute', '279', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('454', '8', '1', '2130706433', 'attribute', '280', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('455', '8', '1', '2130706433', 'attribute', '281', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('456', '8', '1', '2130706433', 'attribute', '282', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('457', '8', '1', '2130706433', 'attribute', '283', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('458', '8', '1', '2130706433', 'attribute', '284', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('459', '8', '1', '2130706433', 'attribute', '285', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('460', '8', '1', '2130706433', 'attribute', '286', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('461', '8', '1', '2130706433', 'attribute', '287', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('462', '8', '1', '2130706433', 'attribute', '288', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('463', '8', '1', '2130706433', 'attribute', '289', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('464', '8', '1', '2130706433', 'attribute', '290', '操作url：/admin.php?s=/Model/generate.html', '1', '1464356213');
INSERT INTO `sys_action_log` VALUES ('465', '7', '1', '2130706433', 'model', '21', '操作url：/admin.php?s=/Model/update.html', '1', '1464356352');
INSERT INTO `sys_action_log` VALUES ('466', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-31 10:58登录了后台', '1', '1464663483');
INSERT INTO `sys_action_log` VALUES ('469', '1', '1', '2130706433', 'member', '1', 'admin在2016-05-31 11:39登录了后台', '1', '1464665972');
INSERT INTO `sys_action_log` VALUES ('470', '7', '1', '2130706433', 'model', '4', '操作url：/admin.php?s=/Model/update.html', '1', '1464675249');
INSERT INTO `sys_action_log` VALUES ('471', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464681501');
INSERT INTO `sys_action_log` VALUES ('472', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464681592');
INSERT INTO `sys_action_log` VALUES ('473', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464681642');
INSERT INTO `sys_action_log` VALUES ('474', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464681816');
INSERT INTO `sys_action_log` VALUES ('475', '7', '1', '2130706433', 'model', '13', '操作url：/admin.php?s=/Model/update.html', '1', '1464685303');
INSERT INTO `sys_action_log` VALUES ('476', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-01 08:59登录了后台', '1', '1464742762');
INSERT INTO `sys_action_log` VALUES ('477', '7', '1', '2130706433', 'model', '7', '操作url：/admin.php?s=/Model/update.html', '1', '1464744668');
INSERT INTO `sys_action_log` VALUES ('478', '7', '1', '2130706433', 'model', '18', '操作url：/admin.php?s=/Model/update.html', '1', '1464746533');
INSERT INTO `sys_action_log` VALUES ('479', '7', '1', '2130706433', 'model', '19', '操作url：/admin.php?s=/Model/update.html', '1', '1464746845');
INSERT INTO `sys_action_log` VALUES ('480', '7', '1', '2130706433', 'model', '9', '操作url：/admin.php?s=/Model/update.html', '1', '1464752523');
INSERT INTO `sys_action_log` VALUES ('481', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-01 13:40登录了后台', '1', '1464759630');
INSERT INTO `sys_action_log` VALUES ('482', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464771425');
INSERT INTO `sys_action_log` VALUES ('483', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464771597');
INSERT INTO `sys_action_log` VALUES ('484', '10', '1', '2130706433', 'Menu', '146', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464772418');
INSERT INTO `sys_action_log` VALUES ('485', '10', '1', '2130706433', 'Menu', '146', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464772581');
INSERT INTO `sys_action_log` VALUES ('486', '8', '1', '2130706433', 'attribute', '291', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('487', '8', '1', '2130706433', 'attribute', '292', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('488', '8', '1', '2130706433', 'attribute', '293', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('489', '8', '1', '2130706433', 'attribute', '294', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('490', '8', '1', '2130706433', 'attribute', '295', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('491', '8', '1', '2130706433', 'attribute', '296', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('492', '8', '1', '2130706433', 'attribute', '297', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('493', '8', '1', '2130706433', 'attribute', '298', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('494', '8', '1', '2130706433', 'attribute', '299', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('495', '8', '1', '2130706433', 'attribute', '300', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('496', '8', '1', '2130706433', 'attribute', '301', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('497', '8', '1', '2130706433', 'attribute', '302', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('498', '8', '1', '2130706433', 'attribute', '303', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('499', '8', '1', '2130706433', 'attribute', '304', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('500', '8', '1', '2130706433', 'attribute', '305', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('501', '8', '1', '2130706433', 'attribute', '306', '操作url：/admin.php?s=/Model/generate.html', '1', '1464772695');
INSERT INTO `sys_action_log` VALUES ('502', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464773268');
INSERT INTO `sys_action_log` VALUES ('503', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464773478');
INSERT INTO `sys_action_log` VALUES ('504', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464773631');
INSERT INTO `sys_action_log` VALUES ('505', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464773957');
INSERT INTO `sys_action_log` VALUES ('506', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464773983');
INSERT INTO `sys_action_log` VALUES ('507', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464774690');
INSERT INTO `sys_action_log` VALUES ('508', '7', '1', '2130706433', 'model', '22', '操作url：/admin.php?s=/Model/update.html', '1', '1464774710');
INSERT INTO `sys_action_log` VALUES ('509', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-01 19:51登录了后台', '1', '1464781873');
INSERT INTO `sys_action_log` VALUES ('510', '11', '1', '2130706433', 'category', '1', '操作url：/admin.php?s=/Category/edit.html', '1', '1464794659');
INSERT INTO `sys_action_log` VALUES ('511', '11', '1', '2130706433', 'category', '2', '操作url：/admin.php?s=/Category/edit.html', '1', '1464794666');
INSERT INTO `sys_action_log` VALUES ('512', '11', '1', '2130706433', 'category', '39', '操作url：/admin.php?s=/Category/add.html', '1', '1464794769');
INSERT INTO `sys_action_log` VALUES ('513', '11', '1', '2130706433', 'category', '40', '操作url：/admin.php?s=/Category/add.html', '1', '1464794803');
INSERT INTO `sys_action_log` VALUES ('514', '11', '1', '2130706433', 'category', '40', '操作url：/admin.php?s=/Category/edit.html', '1', '1464794821');
INSERT INTO `sys_action_log` VALUES ('515', '11', '1', '2130706433', 'category', '40', '操作url：/admin.php?s=/Category/edit.html', '1', '1464794831');
INSERT INTO `sys_action_log` VALUES ('516', '11', '1', '2130706433', 'category', '39', '操作url：/admin.php?s=/Category/edit.html', '1', '1464794833');
INSERT INTO `sys_action_log` VALUES ('517', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-02 08:06登录了后台', '1', '1464825966');
INSERT INTO `sys_action_log` VALUES ('518', '11', '1', '2130706433', 'category', '41', '操作url：/admin.php?s=/Category/add.html', '1', '1464826817');
INSERT INTO `sys_action_log` VALUES ('519', '11', '1', '2130706433', 'category', '42', '操作url：/admin.php?s=/Category/add.html', '1', '1464826928');
INSERT INTO `sys_action_log` VALUES ('520', '11', '1', '2130706433', 'category', '43', '操作url：/admin.php?s=/Category/add.html', '1', '1464826955');
INSERT INTO `sys_action_log` VALUES ('521', '11', '1', '2130706433', 'category', '44', '操作url：/admin.php?s=/Category/add.html', '1', '1464827047');
INSERT INTO `sys_action_log` VALUES ('522', '11', '1', '2130706433', 'category', '45', '操作url：/admin.php?s=/Category/add.html', '1', '1464827079');
INSERT INTO `sys_action_log` VALUES ('523', '11', '1', '2130706433', 'category', '46', '操作url：/admin.php?s=/Category/add.html', '1', '1464827119');
INSERT INTO `sys_action_log` VALUES ('524', '11', '1', '2130706433', 'category', '47', '操作url：/admin.php?s=/Category/add.html', '1', '1464827148');
INSERT INTO `sys_action_log` VALUES ('525', '11', '1', '2130706433', 'category', '48', '操作url：/admin.php?s=/Category/add.html', '1', '1464827180');
INSERT INTO `sys_action_log` VALUES ('526', '11', '1', '2130706433', 'category', '41', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827190');
INSERT INTO `sys_action_log` VALUES ('527', '11', '1', '2130706433', 'category', '47', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827198');
INSERT INTO `sys_action_log` VALUES ('528', '11', '1', '2130706433', 'category', '46', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827200');
INSERT INTO `sys_action_log` VALUES ('529', '11', '1', '2130706433', 'category', '45', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827202');
INSERT INTO `sys_action_log` VALUES ('530', '11', '1', '2130706433', 'category', '44', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827205');
INSERT INTO `sys_action_log` VALUES ('531', '11', '1', '2130706433', 'category', '43', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827207');
INSERT INTO `sys_action_log` VALUES ('532', '11', '1', '2130706433', 'category', '42', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827209');
INSERT INTO `sys_action_log` VALUES ('533', '11', '1', '2130706433', 'category', '48', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827211');
INSERT INTO `sys_action_log` VALUES ('534', '11', '1', '2130706433', 'category', '2', '操作url：/admin.php?s=/Category/edit.html', '1', '1464827285');
INSERT INTO `sys_action_log` VALUES ('535', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-02 08:49登录了后台', '1', '1464828565');
INSERT INTO `sys_action_log` VALUES ('536', '10', '1', '2130706433', 'Menu', '183', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464828772');
INSERT INTO `sys_action_log` VALUES ('537', '10', '1', '2130706433', 'Menu', '184', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464828824');
INSERT INTO `sys_action_log` VALUES ('538', '10', '1', '2130706433', 'Menu', '185', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464828857');
INSERT INTO `sys_action_log` VALUES ('539', '10', '1', '2130706433', 'Menu', '187', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464828900');
INSERT INTO `sys_action_log` VALUES ('540', '10', '1', '2130706433', 'Menu', '188', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464828921');
INSERT INTO `sys_action_log` VALUES ('541', '10', '1', '2130706433', 'Menu', '186', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464829107');
INSERT INTO `sys_action_log` VALUES ('542', '9', '1', '2130706433', 'channel', '2', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464829163');
INSERT INTO `sys_action_log` VALUES ('543', '9', '1', '2130706433', 'channel', '3', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464829214');
INSERT INTO `sys_action_log` VALUES ('544', '9', '1', '2130706433', 'channel', '3', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464829237');
INSERT INTO `sys_action_log` VALUES ('545', '9', '1', '2130706433', 'channel', '3', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464829245');
INSERT INTO `sys_action_log` VALUES ('546', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464829361');
INSERT INTO `sys_action_log` VALUES ('547', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464829583');
INSERT INTO `sys_action_log` VALUES ('548', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464829794');
INSERT INTO `sys_action_log` VALUES ('549', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464829883');
INSERT INTO `sys_action_log` VALUES ('550', '9', '1', '2130706433', 'channel', '2', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464830096');
INSERT INTO `sys_action_log` VALUES ('551', '7', '1', '2130706433', 'model', '14', '操作url：/admin.php?s=/Model/update.html', '1', '1464830093');
INSERT INTO `sys_action_log` VALUES ('552', '9', '1', '2130706433', 'channel', '2', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464830131');
INSERT INTO `sys_action_log` VALUES ('553', '9', '1', '2130706433', 'channel', '3', '操作url：/admin.php?s=/Channel/edit.html', '1', '1464830178');
INSERT INTO `sys_action_log` VALUES ('554', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-02 11:33登录了后台', '1', '1464838402');
INSERT INTO `sys_action_log` VALUES ('555', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-02 16:13登录了后台', '1', '1464855194');
INSERT INTO `sys_action_log` VALUES ('556', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-02 16:36登录了后台', '1', '1464856573');
INSERT INTO `sys_action_log` VALUES ('557', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 08:24登录了后台', '1', '1464913471');
INSERT INTO `sys_action_log` VALUES ('558', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 08:57登录了后台', '1', '1464915471');
INSERT INTO `sys_action_log` VALUES ('559', '10', '1', '2130706433', 'Menu', '193', '操作url：/admin.php?s=/Menu/add.html', '1', '1464915697');
INSERT INTO `sys_action_log` VALUES ('560', '10', '1', '2130706433', 'Menu', '193', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464915748');
INSERT INTO `sys_action_log` VALUES ('561', '10', '1', '2130706433', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/193.html', '1', '1464915771');
INSERT INTO `sys_action_log` VALUES ('562', '10', '1', '2130706433', 'Menu', '194', '操作url：/admin.php?s=/Menu/add.html', '1', '1464915806');
INSERT INTO `sys_action_log` VALUES ('563', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 09:16登录了后台', '1', '1464916575');
INSERT INTO `sys_action_log` VALUES ('564', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 09:23登录了后台', '1', '1464917038');
INSERT INTO `sys_action_log` VALUES ('565', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 09:44登录了后台', '1', '1464918276');
INSERT INTO `sys_action_log` VALUES ('566', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 11:27登录了后台', '1', '1464924452');
INSERT INTO `sys_action_log` VALUES ('567', '10', '1', '2130706433', 'Menu', '195', '操作url：/admin.php?s=/Menu/add.html', '1', '1464924870');
INSERT INTO `sys_action_log` VALUES ('568', '10', '1', '2130706433', 'Menu', '195', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464924896');
INSERT INTO `sys_action_log` VALUES ('569', '7', '1', '2130706433', 'model', '21', '操作url：/admin.php?s=/Model/update.html', '1', '1464925506');
INSERT INTO `sys_action_log` VALUES ('570', '10', '1', '2130706433', 'Menu', '196', '操作url：/admin.php?s=/Menu/add.html', '1', '1464925969');
INSERT INTO `sys_action_log` VALUES ('571', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 11:53登录了后台', '1', '1464926010');
INSERT INTO `sys_action_log` VALUES ('572', '10', '1', '2130706433', 'Menu', '196', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464926091');
INSERT INTO `sys_action_log` VALUES ('573', '10', '1', '2130706433', 'Menu', '196', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464926111');
INSERT INTO `sys_action_log` VALUES ('574', '10', '1', '2130706433', 'Menu', '195', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464926127');
INSERT INTO `sys_action_log` VALUES ('575', '7', '1', '2130706433', 'model', '21', '操作url：/admin.php?s=/Model/update.html', '1', '1464926439');
INSERT INTO `sys_action_log` VALUES ('576', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464934087');
INSERT INTO `sys_action_log` VALUES ('577', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 14:46登录了后台', '1', '1464936395');
INSERT INTO `sys_action_log` VALUES ('578', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464940534');
INSERT INTO `sys_action_log` VALUES ('579', '7', '1', '2130706433', 'model', '20', '操作url：/admin.php?s=/Model/update.html', '1', '1464940574');
INSERT INTO `sys_action_log` VALUES ('580', '10', '1', '2130706433', 'Menu', '148', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464942166');
INSERT INTO `sys_action_log` VALUES ('581', '10', '1', '2130706433', 'Menu', '149', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464942197');
INSERT INTO `sys_action_log` VALUES ('582', '1', '1', '-1062723602', 'member', '1', 'admin在2016-06-03 16:41登录了后台', '1', '1464943282');
INSERT INTO `sys_action_log` VALUES ('583', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 17:02登录了后台', '1', '1464944521');
INSERT INTO `sys_action_log` VALUES ('584', '10', '1', '2130706433', 'Menu', '149', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464944727');
INSERT INTO `sys_action_log` VALUES ('585', '10', '1', '2130706433', 'Menu', '149', '操作url：/admin.php?s=/Menu/edit.html', '1', '1464944737');
INSERT INTO `sys_action_log` VALUES ('586', '7', '1', '2130706433', 'model', '23', '操作url：/admin.php?s=/Model/update.html', '1', '1464945678');
INSERT INTO `sys_action_log` VALUES ('587', '8', '1', '2130706433', 'attribute', '307', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('588', '8', '1', '2130706433', 'attribute', '308', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('589', '8', '1', '2130706433', 'attribute', '309', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('590', '8', '1', '2130706433', 'attribute', '310', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('591', '8', '1', '2130706433', 'attribute', '311', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('592', '8', '1', '2130706433', 'attribute', '312', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('593', '8', '1', '2130706433', 'attribute', '313', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('594', '8', '1', '2130706433', 'attribute', '314', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('595', '8', '1', '2130706433', 'attribute', '315', '操作url：/admin.php?s=/Model/generate.html', '1', '1464945956');
INSERT INTO `sys_action_log` VALUES ('596', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-03 17:28登录了后台', '1', '1464946129');
INSERT INTO `sys_action_log` VALUES ('597', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-04 09:17登录了后台', '1', '1465003055');
INSERT INTO `sys_action_log` VALUES ('598', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-04 09:37登录了后台', '1', '1465004249');
INSERT INTO `sys_action_log` VALUES ('599', '10', '1', '2130706433', 'Menu', '150', '操作url：/admin.php?s=/Menu/edit.html', '1', '1465006721');
INSERT INTO `sys_action_log` VALUES ('600', '10', '1', '2130706433', 'Menu', '197', '操作url：/admin.php?s=/Menu/add.html', '1', '1465007444');
INSERT INTO `sys_action_log` VALUES ('601', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-04 12:54登录了后台', '1', '1465016053');
INSERT INTO `sys_action_log` VALUES ('602', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-04 14:51登录了后台', '1', '1465023082');
INSERT INTO `sys_action_log` VALUES ('603', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-04 15:38登录了后台', '1', '1465025928');
INSERT INTO `sys_action_log` VALUES ('604', '1', '1', '2130706433', 'member', '1', 'admin在2016-06-04 16:30登录了后台', '1', '1465029032');
INSERT INTO `sys_action_log` VALUES ('605', '6', '1', '2130706433', 'config', '52', '操作url：/admin.php?s=/Config/edit.html', '1', '1465029259');
INSERT INTO `sys_action_log` VALUES ('606', '6', '1', '2130706433', 'config', '44', '操作url：/admin.php?s=/Config/edit.html', '1', '1465029306');
INSERT INTO `sys_action_log` VALUES ('607', '6', '1', '2130706433', 'config', '10', '操作url：/admin.php?s=/Config/edit.html', '1', '1465029319');
INSERT INTO `sys_action_log` VALUES ('608', '6', '1', '2130706433', 'config', '0', '操作url：/admin.php?s=/Config/del/id/35.html', '1', '1465029460');

-- -----------------------------
-- Table structure for `sys_addons`
-- -----------------------------
DROP TABLE IF EXISTS `sys_addons`;
CREATE TABLE `sys_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `sys_addons`
-- -----------------------------
INSERT INTO `sys_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `sys_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `sys_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `sys_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `sys_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `sys_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `sys_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');

-- -----------------------------
-- Table structure for `sys_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `sys_attachment`;
CREATE TABLE `sys_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `sys_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `sys_attribute`;
CREATE TABLE `sys_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=316 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `sys_attribute`
-- -----------------------------
INSERT INTO `sys_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('33', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('34', 'sort', '排序', 'int(10) unsigned NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('35', 'short', '游戏简写', 'varchar(20) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('36', 'game_type_id', '游戏类型id', 'int(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('37', 'game_type_name', '游戏类型名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('38', 'game_score', '游戏评分', 'double(3,0) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('39', 'features', '游戏特征', 'varchar(50) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('40', 'recommend_level', '', 'double(3,0) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('41', 'version', '版本号', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('42', 'game_size', '游戏大小', 'varchar(10) NULL ', 'string', '0', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('43', 'icon', '游戏图标', 'int(11) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('44', 'cover', '游戏封面', 'int(11) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('45', 'screenshot', '游戏截图', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('46', 'introduction', '游戏简介', 'varchar(300) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('47', 'and_dow_address', '安卓游戏下载地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('48', 'ios_dow_address', 'ios游戏下载地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('49', 'game_address', '外部链接游戏地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('50', 'dow_num', '游戏下载数量', 'int(10) NULL ', 'string', '0', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('51', 'game_status', '游戏状态(0:关闭,1:开启)', 'tinyint(2) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('52', 'recommend_status', '推荐状态(0:否,1是)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('53', 'pay_status', '充值状态(0:关闭,1:开启)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('54', 'dow_status', '下载状态(0:关闭,1:开启)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('55', 'developers', '开发商', 'varchar(30) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('56', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('57', 'discount', '折扣', 'int(3) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('58', 'language', '语言', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('59', 'game_appid', '游戏appid', 'varchar(32) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('60', 'game_coin_name', '游戏币名称', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('61', 'game_coin_ration', '游戏币比例', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('62', 'type_name', '游戏类型名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('63', 'status', '状态(-1:删除,1:正常)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('64', 'status_show', '显示状态(0:不显示,1:显示)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('65', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('66', 'op_nickname', '操作人昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('67', 'create_time', '添加时间', 'int(11) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('68', 'game_id', '游戏id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('69', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('70', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('71', 'server_num', '对接区服id', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('72', 'recommend_status', '推荐状态(0:否,1:是)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('73', 'show_status', '显示状态(0:否,1:是)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('74', 'stop_status', '是否停服(0:否,1:是)', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('75', 'area_status', '区服状态(0:正常,1拥挤,2爆满)', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('76', 'icon', '区服图标', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('77', 'start_time', '开始时间', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('78', 'desride', '描述', 'varchar(300) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('79', 'prompt', '停服提示', 'varchar(300) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('80', 'parent_id', '父类id', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('81', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('82', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('83', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('84', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('85', 'server_name', '区服名称', 'int(30) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('86', 'giftbag_name', '礼包名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('87', 'giftbag_type', '礼包类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('88', 'level', '领取等级', 'int(3) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('89', 'sort', '排序', 'int(10) NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('90', 'status', '状态', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('91', 'call_api', '调用接口', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('92', 'tong_server', '是否通服', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('93', 'novice', '激活码', 'varchar(3000) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('94', 'digest', '摘要', 'varchar(300) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('95', 'desribe', '描述', 'varchar(300) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('96', 'start_time', '开始时间', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('97', 'end_time', '结束时间', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('98', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('99', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('100', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('101', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('102', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('103', 'gift_id', '礼包id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('104', 'gift_name', '礼包名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('105', 'status', '状态(0:未使用,1:已使用)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('106', 'novice', '激活码', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('107', 'user_id', '用户id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('108', 'user_account', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('109', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('110', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('111', 'account', '账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('112', 'password', '密码', 'varchar(32) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('113', 'second_pwd', '二级密码', 'varchar(32) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('114', 'nickname', '昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('115', 'mobile_phone', '手机号', 'varchar(11) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('116', 'email', '邮箱', 'varchar(50) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('117', 'real_name', '真实姓名', 'varchar(10) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('118', 'bank_name', '银行', 'varchar(50) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('119', 'bank_card', '银行卡', 'varchar(20) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('120', 'money', '金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('121', 'total_money', '总金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('122', 'balance_coin', '平台币', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('123', 'promote_type', '推广员类型', 'int(2) NULL ', 'string', '1', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('124', 'status', '状态', 'int(11) NULL ', 'string', '1', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('125', 'parent_id', '父类ID', 'int(11) NULL ', 'string', '0', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('126', 'referee_id', '推荐人ID', 'int(11) NULL ', 'string', '0', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('127', 'create_time', '添加时间', 'int(11) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('128', 'admin_id', '管理员id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('129', 'user_id', '用户id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('130', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('131', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('132', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('133', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('134', 'prmoote_id_to', '修改后推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('135', 'promot_account_to', '修改后推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('136', 'remark', '备注', 'varchar(100) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('137', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('138', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('139', 'op_account', '操作人账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('140', 'account', '登陆账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('141', 'password', '登陆密码', 'varchar(32) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('142', 'nickname', '昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('143', 'email', '邮箱', 'varchar(50) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('144', 'phone', '手机号码', 'varchar(15) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('145', 'real_name', '真实姓名', 'varchar(20) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('146', 'idcard', '身份证', 'varchar(20) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('147', 'vip_level', 'vip等级', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('148', 'cumulative', '累计充值', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('149', 'balance', '余额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('150', 'anti_addiction', '防沉迷', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('151', 'lock_status', '锁定状态', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('152', 'register_way', '注册方式', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('153', 'register_time', '注册时间', 'int(11) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('154', 'login_time', '登陆时间', 'int(11) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('155', 'register_ip', '注册ip', 'varchar(16) NOT NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('156', 'login_ip', '登陆ip', 'varchar(16) NOT NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('157', 'promote_id', '推广id', 'int(11) NOT NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('158', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('159', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('160', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('161', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('162', 'game_id', '游戏id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('163', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('164', 'game_appid', '游戏appid', 'varchar(32) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('165', 'server_id', '区服id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('166', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('167', 'role_id', '角色', 'int(11) NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('168', 'bind_balance', '绑定平台币', 'double NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('169', 'role_name', '角色名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('170', 'role_level', '等级', 'int(3) NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('171', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('172', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('173', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('174', 'game_name', ' 游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('175', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('176', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('177', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('178', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('179', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('180', 'login_time', '登陆时间', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('181', 'login_ip', '登陆ip', 'varchar(20) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('182', 'type', '类型(1:游戏登陆,2:PC登陆)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('183', 'user_id', ' 用户ID', 'int(11) NOT NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('184', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('185', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('186', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('187', 'game_appid', '游戏appid', 'varchar(32) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('188', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('189', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('190', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('191', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('192', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('193', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('194', 'pay_order_number', '支付订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('195', 'props_name', '道具名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('196', 'pay_amount', '支付金额', 'double(10,2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('197', 'pay_time', '支付时间', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('198', 'pay_status', '支付状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('199', 'pay_game_status', '游戏支付状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('200', 'pay_way', '支付方式', 'tinyint(2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('201', 'spend_ip', '支付IP', 'varchar(20) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('202', 'title', '广告名称', 'char(80) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('203', 'pos_id', '广告位置', 'int(11) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('204', 'data', '图片地址', 'text NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('205', 'click_count', '点击量', 'int(11) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('206', 'url', '链接地址', 'varchar(500) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('207', 'sort', '排序', 'int(3) unsigned NOT NULL ', 'string', '0', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('208', 'status', '状态（0：禁用，1：正常）', 'tinyint(2) NOT NULL ', 'string', '1', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('209', 'create_time', '开始时间', 'int(11) unsigned NOT NULL ', 'string', '0', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('210', 'start_time', '', 'int(11) NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('211', 'end_time', '结束时间', 'int(11) unsigned NULL ', 'string', '0', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('212', 'target', '', 'varchar(20) NULL ', 'string', '_blank', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('213', 'name', '', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('214', 'title', '广告位置名称', 'char(80) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('215', 'module', '所在模块 模块/控制器/方法', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('216', 'type', '广告位类型 \r\n1.单图\r\n2.多图\r\n3.文字链接\r\n4.代码', 'int(11) unsigned NOT NULL ', 'string', '1', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('217', 'status', '状态（0：禁用，1：正常）', 'tinyint(2) NOT NULL ', 'string', '1', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('218', 'data', '额外的数据', 'varchar(500) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('219', 'width', '广告位置宽度', 'char(20) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('220', 'height', '广告位置高度', 'char(20) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('221', 'margin', '边缘', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('222', 'padding', '留白', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('223', 'theme', '适用主题，默认为all，通用', 'varchar(50) NOT NULL ', 'string', 'all', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('224', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('225', 'pay_order_number', '支付订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('226', 'user_id', '用户id', 'int(11) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('227', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('228', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('229', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('230', 'promote_account', '推广账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('231', 'pay_amount', '充值金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('232', 'pay_status', '充值状态', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('233', 'pay_way', '支付方式', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('234', 'pay_source', '支付来源', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('235', 'pay_ip', '充值IP', 'varchar(20) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('236', 'create_time', '支付时间', 'int(11) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233085', '1464233085', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('237', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233863', '1464233863', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('238', 'pay_order_number', '商户订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233863', '1464233863', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('239', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233863', '1464233863', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('240', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('241', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('242', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('243', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('244', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('245', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('246', 'amount', '充值金额', 'double(10,2) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('247', 'remark', '备注', 'varchar(100) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('248', 'status', '状态', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('249', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('250', 'op_account', '操作人账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('251', 'create_time', '时间', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('252', 'user_id', '用户id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('253', 'user_account', '用户账号', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('254', 'user_nickname', '用户昵称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('255', 'game_id', '游戏id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('256', 'game_appid', '游戏appid', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('257', 'game_name', '游戏名称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('258', 'order_number', '订单号', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('259', 'pay_order_number', '商户订单号', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('260', 'props_name', '道具名称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('261', 'pay_amount', '金额', 'double(10,2) NOT NULL ', 'string', '0.00', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('262', 'pay_time', '支付时间', 'int(11) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('263', 'pay_status', '支付状态', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('264', 'pay_game_status', '游戏支付状态', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('265', 'pay_way', '支付方式', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('266', 'pay_source', '支付来源', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('267', 'spend_ip', '支付ip', 'varchar(16) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('268', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('269', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('270', 'file_id', '文件id', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('271', 'file_name', '文件名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('272', 'file_url', '文件路径', 'varchar(255) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('273', 'file_size', '文件大小', 'int(11) NOT NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('274', 'file_type', '原包类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('275', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('276', 'op_account', '操作人名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('277', 'remark', '备注', 'varchar(100) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('278', 'create_time', '时间', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('279', 'game_id', '游戏ID', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('280', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('281', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('282', 'promote_account', '推广账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('283', 'ratio', '分成比例', 'int(3) NULL ', 'string', '0', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('284', 'apply_time', '申请时间', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('285', 'status', '审核状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('286', 'enable_status', '操作状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('287', 'pack_url', '游戏包地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('288', 'dow_url', '下载地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('289', 'dispose_id', '操作人', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('290', 'dispose_time', '操作时间', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('291', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('292', 'pay_order_number', '支付订单号 ', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('293', 'game_id', '游戏ID', 'int(11) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('294', 'game_appid', '游戏APPID', 'varchar(32) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('295', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('296', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '0', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('297', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('298', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('299', 'user_account', '玩家账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('300', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('301', 'amount', '支付金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('302', 'real_amount', '实际金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('303', 'status', '支付状态', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('304', 'pay_type', '类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('305', 'create_time', '时间', 'int(11) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('306', 'zhekou', '折扣比例', 'int(11) NOT NULL ', 'string', '0', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('307', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('308', 'game_id', '游戏ID', 'varchar(32) NULL ', 'string', '', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('309', 'spend_time', '消费时间', 'int(11) NULL ', 'string', '', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('310', 'reg_num', '注册人数', 'int(10) NULL ', 'string', '0', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('311', 'spend_num', '消费人数', 'int(10) NULL ', 'string', '0', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('312', 'money', '金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('313', 'real_money', '实际金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('314', 'status', '结算状态', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('315', 'type', '类型', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `sys_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_extend`;
CREATE TABLE `sys_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `sys_auth_extend`
-- -----------------------------
INSERT INTO `sys_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `sys_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `sys_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `sys_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `sys_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_group`;
CREATE TABLE `sys_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_auth_group`
-- -----------------------------
INSERT INTO `sys_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,100,102,103');
INSERT INTO `sys_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');

-- -----------------------------
-- Table structure for `sys_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_group_access`;
CREATE TABLE `sys_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_auth_group_access`
-- -----------------------------
INSERT INTO `sys_auth_group_access` VALUES ('2', '1');

-- -----------------------------
-- Table structure for `sys_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_rule`;
CREATE TABLE `sys_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=278 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_auth_rule`
-- -----------------------------
INSERT INTO `sys_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/index', '文章', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('17', 'admin', '1', 'Admin/Article/examine', '审核列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('217', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('218', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Game/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Game/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('221', 'admin', '1', 'Admin/GameType/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('222', 'admin', '1', 'Admin/GameType/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Server/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Server/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Giftbag/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('226', 'admin', '1', 'Admin/Giftbag/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Promote/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('228', 'admin', '1', 'Admin/Promote/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('229', 'admin', '1', 'Admin/Adv/edit_media_adv_pos', '编辑媒体广告位', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('230', 'admin', '1', 'Admin/Adv/edit_app_adv_pos', '编辑app广告位', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Adv/media_adv_lists', '媒体广告列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Adv/edit_media_adv', '编辑媒体广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Adv/add_media_adv', '新增媒体广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Adv/app_adv_lists', 'app广告列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('235', 'admin', '1', 'Admin/Adv/add_app_adv', '新增app广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('236', 'admin', '1', 'Admin/Adv/edit_app_adv', '编辑app广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('237', 'admin', '1', 'Admin/Adv/edit_adv', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('238', 'admin', '1', 'Admin/GameSource/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('239', 'admin', '1', 'Admin/GameSource/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('240', 'admin', '1', 'Admin/Mend/edit', '渠道补链', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('241', 'admin', '1', 'Admin/Game/lists', '游戏管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('242', 'admin', '1', 'Admin/Promote/lists', '渠道管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('243', 'admin', '1', 'Admin/Site/media', '基本配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('244', 'admin', '1', 'Admin/Stat/daily', '日常统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('245', 'admin', '1', 'Admin/GameType/lists', '游戏分类', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('246', 'admin', '1', 'Admin/Mend/lists', '渠道补链', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('247', 'admin', '1', 'Admin/Adv/media_adv_pos_lists', '广告管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('248', 'admin', '1', 'Admin/#', '渠道提现', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('249', 'admin', '1', 'Admin/Server/lists', '游戏区服', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('250', 'admin', '1', 'Admin/Mend/record', '补链记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('251', 'admin', '1', 'Admin/Logo/media_logo', '图标设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('252', 'admin', '2', 'Admin/Game/lists', '游戏', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('253', 'admin', '1', 'Admin/Promote/ch_reg_list', '渠道注册', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('254', 'admin', '1', 'Admin/Site/app', '基本配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('255', 'admin', '1', 'Admin/GameSource/lists', '游戏原包', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('256', 'admin', '1', 'Admin/Giftbag/lists', '礼包管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('257', 'admin', '2', 'Admin/Promote/lists', '渠道', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('258', 'admin', '1', 'Admin/Adv/app_adv_pos_lists', '广告管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('259', 'admin', '1', 'Admin/Giftbag/record', '领取记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('260', 'admin', '1', 'Admin/Promote/spend_list', '渠道充值', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('261', 'admin', '2', 'Admin/Site/media', '站点', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('262', 'admin', '1', 'Admin/Adv/adv_lists', '广告列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('263', 'admin', '1', 'Admin/Member/user_info', '平台用户', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('264', 'admin', '2', 'Admin/Stat/daily', '统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('265', 'admin', '1', 'Admin/Logo/app_logo', '图标设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('266', 'admin', '1', 'Admin/Tool/smsset', '短信设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('267', 'admin', '1', 'Admin/Member/login_record', '登陆记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('268', 'admin', '1', 'Admin/Site/channel', '基本配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('269', 'admin', '1', 'Admin/Tool/storage', '文件存储', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('270', 'admin', '1', 'Admin/Spend/lists', '游戏消费记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('271', 'admin', '1', 'Admin/Logo/channel_logo', '图标设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('272', 'admin', '1', 'Admin/Tool/payset', '支付设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('273', 'admin', '1', 'Admin/Deposit/lists', '平台币充值记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('274', 'admin', '1', 'Admin/Tool/email', '邮件设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('275', 'admin', '1', 'Admin/Provide/lists', '平台币发放记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('276', 'admin', '1', 'Admin/Tool/thirdparty', '第三方登陆', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('277', 'admin', '1', 'Admin/BindSpend/lists', '平台币使用记录', '1', '');

-- -----------------------------
-- Table structure for `sys_category`
-- -----------------------------
DROP TABLE IF EXISTS `sys_category`;
CREATE TABLE `sys_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `groups` varchar(255) NOT NULL DEFAULT '' COMMENT '分组定义',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `sys_category`
-- -----------------------------
INSERT INTO `sys_category` VALUES ('1', 'blog', '渠道站', '0', '0', '10', '', '', '', '', '', '', '', '2,3', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1464794659', '1', '0', '');
INSERT INTO `sys_category` VALUES ('2', 'tui_gg', '游戏公告', '1', '1', '10', '', '', '', '', '', '', '', '2', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1464827285', '1', '0', '');
INSERT INTO `sys_category` VALUES ('39', 'tui_zx', '游戏资讯', '1', '1', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464794769', '1464794833', '1', '0', '');
INSERT INTO `sys_category` VALUES ('40', 'tui_about', '关于我们', '1', '3', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464794803', '1464794831', '1', '0', '');
INSERT INTO `sys_category` VALUES ('41', 'media', '媒体站', '0', '1', '10', '', '', '', '', '', '', '', '2', '2', '2,1', '0', '1', '1', '0', '0', '', '', '1464826817', '1464827190', '1', '0', '');
INSERT INTO `sys_category` VALUES ('42', 'media_gg', '游戏公告', '41', '6', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464826928', '1464827209', '1', '0', '');
INSERT INTO `sys_category` VALUES ('43', 'media_new', '游戏新闻', '41', '5', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464826955', '1464827207', '1', '0', '');
INSERT INTO `sys_category` VALUES ('44', 'media_activity', '游戏活动', '41', '4', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827047', '1464827205', '1', '0', '');
INSERT INTO `sys_category` VALUES ('45', 'media_partner', '合作伙伴', '41', '3', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827079', '1464827202', '1', '0', '');
INSERT INTO `sys_category` VALUES ('46', 'media_collaborate', '商务合作', '41', '2', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827119', '1464827200', '1', '0', '');
INSERT INTO `sys_category` VALUES ('47', 'media_about', '关于我们', '41', '1', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827148', '1464827198', '1', '0', '');
INSERT INTO `sys_category` VALUES ('48', 'media_supervise', '家长监督', '41', '7', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827180', '1464827211', '1', '0', '');

-- -----------------------------
-- Table structure for `sys_channel`
-- -----------------------------
DROP TABLE IF EXISTS `sys_channel`;
CREATE TABLE `sys_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_channel`
-- -----------------------------
INSERT INTO `sys_channel` VALUES ('1', '0', '首页', 'Index/index', '3', '1379475111', '1379923177', '1', '0');
INSERT INTO `sys_channel` VALUES ('2', '0', '游戏公告', 'Article/lists?category=tui_gg', '2', '1379475131', '1464830131', '1', '0');
INSERT INTO `sys_channel` VALUES ('3', '0', '游戏资讯', 'Article/lists?category=tui_zx', '1', '1379475154', '1464830178', '1', '0');

-- -----------------------------
-- Table structure for `sys_config`
-- -----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `category` tinyint(3) NOT NULL COMMENT '配置分类',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_config`
-- -----------------------------
INSERT INTO `sys_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '0', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '', '0');
INSERT INTO `sys_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '0', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '', '1');
INSERT INTO `sys_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '0', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '', '8');
INSERT INTO `sys_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '0', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `sys_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '0', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1464137919', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n5:图片', '2');
INSERT INTO `sys_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '0', '1', '', '工业与信息化部备案', '1378900335', '1465029319', '1', '', '9');
INSERT INTO `sys_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '0', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐\r\n2:频道推荐\r\n4:首页推荐', '3');
INSERT INTO `sys_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '0', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `sys_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '0', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `sys_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '0', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `sys_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '0', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `sys_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '0', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `sys_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '0', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `sys_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '0', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `sys_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '0', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '15', '10');
INSERT INTO `sys_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '0', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `sys_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '0', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `sys_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '0', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `sys_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '0', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `sys_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '0', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `sys_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '0', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `sys_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '0', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `sys_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `sys_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `sys_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '0', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `sys_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '0', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');
INSERT INTO `sys_config` VALUES ('38', 'PC_SET_TITLE', '1', '媒体官网标题设置', '1', '1', '哈哈', '用于显示媒体官网标题', '1464056166', '1464071718', '1', '哈哈', '0');
INSERT INTO `sys_config` VALUES ('39', 'CONFIG_CATEGORY_LIST', '3', '配置分组', '0', '4', '', '设置分组', '1464057350', '1464075821', '1', '1:媒体官网\r\n2:渠道官网\r\n3:APP设置\r\n4:管理后台', '0');
INSERT INTO `sys_config` VALUES ('40', 'PC_SET_META_KEY', '1', '媒体网站关键词设置', '1', '1', '', '网站关键词', '1464073412', '1464073714', '1', '', '1');
INSERT INTO `sys_config` VALUES ('41', 'PC_SET_META_DESC', '2', '媒体网站描述设置', '1', '1', '', '网站描述', '1464073618', '1464073728', '1', '', '2');
INSERT INTO `sys_config` VALUES ('42', 'PC_SET_COPYRIGHT', '2', '媒体官网版权信息设置', '1', '1', '', '媒体官网版权信息设置', '1464074257', '1464074463', '1', '', '3');
INSERT INTO `sys_config` VALUES ('43', 'PC_SET_LICENSE', '1', '网络文化经营许可证编号', '1', '1', '', '网络文化经营许可证编号', '1464074566', '1464074566', '1', '', '1');
INSERT INTO `sys_config` VALUES ('44', 'PC_SET_FOR_THE_RECORD', '1', '网站备案号', '1', '1', '', '工业与信息化部备案', '1464074923', '1465029306', '1', '', '1');
INSERT INTO `sys_config` VALUES ('45', 'PC_SET_SERVER_TEL', '1', '客服电话', '1', '2', '', '客服联系电话或手机', '1464075195', '1464075195', '1', '', '0');
INSERT INTO `sys_config` VALUES ('46', 'PC_SET_SERVER_QQ', '1', '客服QQ', '1', '2', '', '客服QQ', '1464075627', '1464075647', '1', '', '0');
INSERT INTO `sys_config` VALUES ('47', 'PC_SET_SERVER_EMAIL', '1', '客服邮箱', '1', '2', '', '客服邮箱', '1464075697', '1464075750', '1', '', '0');
INSERT INTO `sys_config` VALUES ('48', 'CH_SET_META_KEY', '1', '媒体网站关键词设置', '2', '1', '', '网站关键词', '1464073412', '1464073714', '1', '手游推广联盟，溪谷渠道合作中心，溪谷游戏渠道联动平台', '1');
INSERT INTO `sys_config` VALUES ('49', 'CH_SET_META_DESC', '2', '媒体网站描述设置', '2', '1', '', '网站描述', '1464073618', '1464073728', '1', '', '2');
INSERT INTO `sys_config` VALUES ('50', 'CH_SET_COPYRIGHT', '2', '媒体官网版权信息设置', '2', '1', '', '媒体官网版权信息设置', '1464074257', '1464074463', '1', '', '3');
INSERT INTO `sys_config` VALUES ('51', 'CH_SET_LICENSE', '1', '网络文化经营许可证编号', '2', '1', '', '网络文化经营许可证编号', '1464074566', '1464074566', '1', '', '1');
INSERT INTO `sys_config` VALUES ('52', 'CH_SET_FOR_THE_RECORD', '1', '网站备案号', '2', '1', '', '工业与信息化部备案', '1464074923', '1465029259', '1', '', '1');
INSERT INTO `sys_config` VALUES ('53', 'CH_SET_SERVER_TEL', '1', '客服电话', '2', '2', '', '客服联系电话或手机', '1464075195', '1464075195', '1', '', '0');
INSERT INTO `sys_config` VALUES ('54', 'CH_SET_SERVER_QQ', '1', '客服QQ', '2', '2', '', '客服QQ', '1464075627', '1464075647', '1', '', '0');
INSERT INTO `sys_config` VALUES ('55', 'CH_SET_SERVER_EMAIL', '1', '客服邮箱', '2', '2', '', '客服邮箱', '1464075697', '1464075750', '1', '', '0');
INSERT INTO `sys_config` VALUES ('56', 'PC_SET_LOGO', '5', '媒体网站logo', '1', '0', '', '120px*40px', '1464137707', '1464138034', '1', '1', '0');
INSERT INTO `sys_config` VALUES ('57', 'PC_SET_QRCODE', '5', '设置媒体官网二维码', '1', '0', '', '设置媒体官网二维码', '1464148155', '1464148155', '1', '', '0');
INSERT INTO `sys_config` VALUES ('58', 'PC_SET_ICO', '5', '设置媒体官网ico图标', '1', '0', '', '设置媒体官网ico图标', '1464148189', '1464148189', '1', '', '0');
INSERT INTO `sys_config` VALUES ('59', 'CH_SET_LOGO', '5', '渠道LOGO设置', '2', '0', '', '120px * 30px', '1464157183', '1464157417', '1', '', '0');
INSERT INTO `sys_config` VALUES ('60', 'CH_SET_QRCODE', '5', '设置渠道官网二维码', '2', '0', '', '120px * 20px', '1464157237', '1464157438', '1', '', '0');
INSERT INTO `sys_config` VALUES ('61', 'CH_SET_ICO', '5', '设置渠道官网ico图标', '2', '0', '', '请上传后缀为.ico的图标', '1464157295', '1464157394', '1', '', '0');
INSERT INTO `sys_config` VALUES ('62', 'APP_SET_COVER', '5', '设置APP开机画面', '3', '0', '', '用户手机APP的初始画面', '1464157375', '1464157691', '1', '', '0');
INSERT INTO `sys_config` VALUES ('63', 'CH_SET_TITLE', '1', '渠道官网标题', '2', '1', '', '渠道官网标题', '1464339818', '1464339818', '1', '溪谷游戏合作平台_手机游戏推广联盟_手游推广员赚钱平台', '0');

-- -----------------------------
-- Table structure for `sys_document`
-- -----------------------------
DROP TABLE IF EXISTS `sys_document`;
CREATE TABLE `sys_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `group_id` smallint(3) unsigned NOT NULL COMMENT '所属分组',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `sys_document`
-- -----------------------------
INSERT INTO `sys_document` VALUES ('1', '1', '', 'OneThink1.1开发版发布', '2', '0', '期待已久的OneThink最新版发布', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '18', '0', '0', '0', '1406001413', '1406001413', '1');
INSERT INTO `sys_document` VALUES ('2', '1', 'wew', '测试目录', '2', '0', 'sf', '0', '0', '2', '1', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1463642161', '1463642161', '2');
INSERT INTO `sys_document` VALUES ('3', '1', 'sdf', '主题信息', '2', '0', '士大夫', '2', '2', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1463642189', '1463642189', '2');
INSERT INTO `sys_document` VALUES ('4', '1', 'yxhdtest', '游戏活动测试', '44', '0', '', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1464831956', '1464831956', '1');
INSERT INTO `sys_document` VALUES ('5', '1', 'gg', '游戏公告测试', '42', '0', '', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1464831977', '1464831977', '1');
INSERT INTO `sys_document` VALUES ('6', '1', 'new', '游戏新闻测试', '43', '0', '', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1464832001', '1464832001', '1');

-- -----------------------------
-- Table structure for `sys_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `sys_document_article`;
CREATE TABLE `sys_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `sys_document_article`
-- -----------------------------
INSERT INTO `sys_document_article` VALUES ('1', '0', '<h1>\r\n	OneThink1.1开发版发布&nbsp;\r\n</h1>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> \r\n</p>\r\n<h2>\r\n	主要特性：\r\n</h2>\r\n<p>\r\n	1. 基于ThinkPHP最新3.2版本。\r\n</p>\r\n<p>\r\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\r\n</p>\r\n<p>\r\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\r\n</p>\r\n<p>\r\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\r\n</p>\r\n<p>\r\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\r\n</p>\r\n<p>\r\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\r\n</p>\r\n<p>\r\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\r\n</p>\r\n<p>\r\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\r\n</p>\r\n<p>\r\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<h2>\r\n	后台主要功能：\r\n</h2>\r\n<p>\r\n	1. 用户Passport系统\r\n</p>\r\n<p>\r\n	2. 配置管理系统&nbsp;\r\n</p>\r\n<p>\r\n	3. 权限控制系统\r\n</p>\r\n<p>\r\n	4. 后台建模系统&nbsp;\r\n</p>\r\n<p>\r\n	5. 多级分类系统&nbsp;\r\n</p>\r\n<p>\r\n	6. 用户行为系统&nbsp;\r\n</p>\r\n<p>\r\n	7. 钩子和插件系统\r\n</p>\r\n<p>\r\n	8. 系统日志系统&nbsp;\r\n</p>\r\n<p>\r\n	9. 数据备份和还原\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink开发团队 2013~2014</strong> \r\n</p>', '', '0');
INSERT INTO `sys_document_article` VALUES ('2', '0', '暗室逢灯<br />', '', '0');
INSERT INTO `sys_document_article` VALUES ('3', '0', '士大夫<br />', '', '0');
INSERT INTO `sys_document_article` VALUES ('4', '0', '游戏活动测试', '', '0');
INSERT INTO `sys_document_article` VALUES ('5', '0', '啥地方', '', '0');
INSERT INTO `sys_document_article` VALUES ('6', '0', '啥地方', '', '0');

-- -----------------------------
-- Table structure for `sys_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `sys_document_download`;
CREATE TABLE `sys_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `sys_file`
-- -----------------------------
DROP TABLE IF EXISTS `sys_file`;
CREATE TABLE `sys_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `sys_file`
-- -----------------------------
INSERT INTO `sys_file` VALUES ('108', 'sdk_test_demo.apk', '575122f939b19.apk', '2016-06-03/', 'apk', 'application/jar', '1197722', '1e29fa8deef7606a1f0e913a977743b4', 'bce92279b9b52cecd45a1bbfa66513f8c346710e', '0', '', '1464935161');

-- -----------------------------
-- Table structure for `sys_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `sys_hooks`;
CREATE TABLE `sys_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_hooks`
-- -----------------------------
INSERT INTO `sys_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `sys_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `sys_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `sys_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `sys_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `sys_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `sys_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `sys_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `sys_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `sys_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `sys_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');

-- -----------------------------
-- Table structure for `sys_member`
-- -----------------------------
DROP TABLE IF EXISTS `sys_member`;
CREATE TABLE `sys_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `sys_member`
-- -----------------------------
INSERT INTO `sys_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '40', '41', '0', '1463641749', '2130706433', '1465029032', '1');
INSERT INTO `sys_member` VALUES ('2', '111111', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1');

-- -----------------------------
-- Table structure for `sys_menu`
-- -----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_menu`
-- -----------------------------
INSERT INTO `sys_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('2', '文章', '0', '2', 'Article/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `sys_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `sys_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('16', '用户', '0', '3', 'User/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('17', '用户信息', '16', '1', 'User/index', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('19', '用户行为', '16', '2', 'User/action', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('27', '权限管理', '16', '3', 'AuthManager/index', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('43', '扩展', '0', '9', 'Addons/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `sys_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `sys_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('68', '系统', '0', '8', 'Config/group', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `sys_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `sys_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('93', '其他', '0', '10', 'other', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('106', '行为日志', '16', '4', 'Action/actionlog', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('108', '修改密码', '16', '5', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('109', '修改昵称', '16', '6', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('122', '数据列表', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('123', '审核列表', '3', '0', 'Article/examine', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('124', '游戏', '0', '4', 'Game/lists', '0', '游戏管理', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('125', '游戏管理', '124', '1', 'Game/lists', '0', '游戏管理', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('126', '新增', '125', '0', 'Game/add', '0', '新增游戏', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('127', '编辑', '125', '0', 'Game/edit', '0', '编辑游戏', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('128', '游戏分类', '124', '2', 'GameType/lists', '0', '游戏类型管理', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('129', '新增', '128', '0', 'GameType/add', '0', '新增游戏类型', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('130', '编辑', '128', '0', 'GameType/edit', '0', '编辑游戏类型', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('131', '游戏区服', '124', '3', 'Server/lists', '0', '游戏区服', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('132', '新增', '131', '0', 'Server/add', '0', '新增区服', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('133', '编辑', '131', '0', 'Server/edit', '0', '编辑游戏区服', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('134', '礼包管理', '124', '5', 'Giftbag/lists', '0', '礼包管理', '礼包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('135', '领取记录', '124', '6', 'Giftbag/record', '0', '礼包管理', '礼包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('136', '新增', '134', '0', 'Giftbag/add', '0', '新增礼包', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('137', '编辑', '134', '0', 'Giftbag/edit', '0', '礼包管理', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('138', '渠道', '0', '5', 'Promote/lists', '0', '渠道管理', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('139', '渠道管理', '138', '1', 'Promote/lists', '0', '渠道管理', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('140', '新增', '139', '0', 'Promote/add', '0', '新增渠道', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('141', '编辑', '139', '0', 'Promote/edit', '0', '编辑渠道', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('142', '渠道补链', '138', '2', 'Mend/lists', '0', '渠道补链', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('143', '补链记录', '138', '3', 'Mend/record', '0', '补链记录', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('144', '渠道注册', '138', '4', 'Promote/ch_reg_list', '0', '渠道注册用户', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('145', '渠道充值', '138', '6', 'Promote/spend_list', '0', '', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('146', '代充记录', '138', '7', 'Promote/agent_list', '0', '', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('147', '代充额度', '138', '8', '#', '0', '', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('148', '渠道对账', '138', '9', 'Query/bill', '0', '', '渠道对账', '0', '1');
INSERT INTO `sys_menu` VALUES ('149', '渠道结算', '138', '10', 'Query/settlement', '0', '', '渠道对账', '0', '1');
INSERT INTO `sys_menu` VALUES ('150', '渠道提现', '138', '11', 'Query/withdraw', '0', '', '渠道对账', '0', '1');
INSERT INTO `sys_menu` VALUES ('151', '平台用户', '16', '7', 'Member/user_info', '0', '', '用户组', '0', '1');
INSERT INTO `sys_menu` VALUES ('152', '登陆记录', '16', '8', 'Member/login_record', '0', '', '用户组', '0', '1');
INSERT INTO `sys_menu` VALUES ('153', '游戏消费记录', '16', '9', 'Spend/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('154', '平台币充值记录', '16', '10', 'Deposit/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('155', '平台币发放记录', '16', '11', 'Provide/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('156', '平台币使用记录', '16', '12', 'BindSpend/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('157', '站点', '0', '6', 'Site/media', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('158', '基本配置', '157', '1', 'Site/media', '0', '媒体官网的基本配置', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('159', '广告管理', '157', '2', 'Adv/media_adv_pos_lists', '0', '', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('160', '统计', '0', '7', 'Stat/daily', '0', '统计模块', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('161', '基本配置', '157', '4', 'Site/app', '0', '', 'APP管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('162', '基本配置', '157', '8', 'Site/channel', '0', '', '渠道站管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('163', '广告管理', '157', '5', 'Adv/app_adv_pos_lists', '0', '', 'APP管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('164', '编辑媒体广告位', '159', '0', 'Adv/edit_media_adv_pos', '0', '编辑媒体广告位', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('165', '编辑app广告位', '163', '0', 'Adv/edit_app_adv_pos', '0', '编辑app广告位', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('166', '媒体广告列表', '159', '0', 'Adv/media_adv_lists', '0', '媒体广告列表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('167', '编辑媒体广告', '159', '0', 'Adv/edit_media_adv', '0', '编辑媒体广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('168', '新增媒体广告', '159', '0', 'Adv/add_media_adv', '0', '新增媒体广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('169', 'app广告列表', '163', '0', 'Adv/app_adv_lists', '0', 'app广告列表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('170', '新增app广告', '163', '0', 'Adv/add_app_adv', '0', '新增app广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('171', '编辑app广告', '163', '0', 'Adv/edit_app_adv', '0', '编辑app广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('172', '广告列表', '157', '6', 'Adv/adv_lists', '0', '', '广告列表', '0', '1');
INSERT INTO `sys_menu` VALUES ('173', '编辑', '172', '0', 'Adv/edit_adv', '0', '编辑广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('174', '图标设置', '157', '3', 'Logo/media_logo', '0', '', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('175', '图标设置', '157', '7', 'Logo/app_logo', '0', '', 'APP管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('176', '图标设置', '157', '9', 'Logo/channel_logo', '0', '', '渠道站管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('177', '短信设置', '68', '7', 'Tool/smsset', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('178', '文件存储', '68', '8', 'Tool/storage', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('179', '支付设置', '68', '9', 'Tool/payset', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('180', '第三方登陆', '68', '11', 'Tool/thirdparty', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('181', '邮件设置', '68', '10', 'Tool/email', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('182', '日常统计', '160', '1', 'Stat/daily', '0', '', '日常统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('183', '来款统计', '160', '2', 'stat/pay_way', '0', '', '日常统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('184', '登陆统计', '160', '3', 'stat/cpa_login', '0', '', 'CPS统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('185', '注册统计', '160', '4', 'stat/cpa_register', '0', '', 'CPS统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('186', '充值统计', '160', '5', 'stat/cpa_spend', '0', '', 'CPS统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('187', '留存统计', '160', '6', 'stat/userretention', '0', '', '运营分析', '0', '1');
INSERT INTO `sys_menu` VALUES ('188', 'ARPU统计', '160', '7', 'stat/userarpu', '0', '', '运营分析', '0', '1');
INSERT INTO `sys_menu` VALUES ('189', '游戏原包', '124', '4', 'GameSource/lists', '0', '', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('190', '新增', '189', '0', 'GameSource/add', '0', '上传游戏原包', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('191', '编辑', '189', '0', 'GameSource/edit', '0', '编辑游戏原包', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('192', '渠道补链', '142', '0', 'Mend/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('194', '用户编辑', '151', '0', 'Member/edit', '0', '', '平台用户', '0', '1');
INSERT INTO `sys_menu` VALUES ('195', '分包管理', '138', '4', 'Apply/lists', '0', '', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('196', '编辑', '195', '0', 'Apply/edit', '0', '', '分包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('197', '提现添加', '150', '0', 'Query/withdraw_add', '0', '', '渠道提现', '0', '1');

-- -----------------------------
-- Table structure for `sys_model`
-- -----------------------------
DROP TABLE IF EXISTS `sys_model`;
CREATE TABLE `sys_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `sys_model`
-- -----------------------------
INSERT INTO `sys_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nview:浏览\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('4', 'game', '游戏', '0', '', '1', '{\"1\":[\"53\",\"54\",\"52\",\"51\",\"49\",\"50\",\"55\",\"56\",\"60\",\"61\",\"59\",\"58\",\"57\",\"48\",\"47\",\"38\",\"39\",\"37\",\"36\",\"34\",\"35\",\"40\",\"41\",\"45\",\"46\",\"44\",\"43\",\"42\",\"33\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nsort:排序\r\ngame_name:游戏名称\r\ngame_type_name:游戏类型\r\ngame_appid:游戏appid\r\ngame_status|get_info_status:游戏状态\r\nrecommend_status|get_info_status*1:推荐状态\r\nid:操作:[EDIT]&id=[id]|编辑,Game/del?ids=[id]|删除', '10', 'game_name', 'game_name', '1463664513', '1464675249', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('5', 'GameType', '游戏类型', '0', '', '1', '{\"1\":[\"66\",\"67\",\"65\",\"64\",\"63\",\"62\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntype_name:游戏类型\r\nstatus_show|get_info_status*8:显示状态\r\nop_nickname:操作人\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,GameType/del?ids=[id]|删除', '10', 'type_name', '', '1463968087', '1463982517', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('6', 'Server', '游戏区服', '0', '', '1', '{\"1\":[\"77\",\"76\",\"78\",\"79\",\"81\",\"80\",\"75\",\"74\",\"70\",\"69\",\"71\",\"72\",\"73\",\"68\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nserver_name:区服名称\r\ngame_name:游戏名称\r\nrecommend_status|get_info_status:推荐状态\r\nstop_status|get_info_status:区服状态\r\nstart_time|set_show_time:开服时间\r\nid:操作:[EDIT]&id=[id]|编辑,Server/del?ids=[id]|删除', '10', 'server_name', '', '1463982982', '1463985396', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('7', 'giftbag', '礼包管理', '0', '', '1', '{\"1\":[\"94\",\"93\",\"92\",\"95\",\"96\",\"98\",\"97\",\"91\",\"90\",\"85\",\"84\",\"83\",\"86\",\"87\",\"89\",\"88\",\"82\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\ngiftbag_name:礼包名称\r\nserver_name:区服名称\r\ngiftbag_type|get_gifttype:类型\r\nstatus|get_info_status:状态\r\nid:操作:[EDIT]&id=[id]|编辑,Giftbag/del?ids=[id]|删除', '10', 'giftbag_name', '', '1463985936', '1464744668', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('8', 'GiftRecord', '礼包记录', '0', '', '1', '{\"1\":[\"107\",\"106\",\"108\",\"109\",\"110\",\"105\",\"104\",\"100\",\"101\",\"102\",\"103\",\"99\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\ngift_name:礼包名称\r\nuser_account:领取用户\r\nnovice:激活码\r\ncreate_time|set_show_time*time:领取时间', '10', 'game_name', '', '1463987676', '1463987992', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('9', 'promote', '渠道管理', '0', '', '1', '{\"1\":[\"123\",\"122\",\"121\",\"124\",\"125\",\"128\",\"127\",\"126\",\"120\",\"119\",\"114\",\"113\",\"112\",\"115\",\"116\",\"118\",\"117\",\"111\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\naccount:账号\r\nreal_name:姓名\r\nmobile_phone:手机\r\nemail:邮箱\r\nstatus|get_info_status*3:状态\r\nadmin_id|get_admin_nickname:所属管理员\r\nid:操作:[EDIT]&id=[id]|查看,Promote/del?ids=[id]|删除', '10', '', '', '1463989240', '1464752523', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('10', 'mend', '补链管理', '0', '', '1', '{\"1\":[\"136\",\"137\",\"138\",\"139\",\"135\",\"134\",\"130\",\"131\",\"132\",\"133\",\"129\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nuser_account:账号\r\nuser_nickname:昵称\r\npromote_id:推广员编号\r\npromote_account:推广员账号\r\npromote_id_to:修改后编号\r\npromote_account_to:修改后账号\r\ncreate_time:时间\r\nop_account:操作人账号', '10', '', '', '1463997570', '1464332332', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('11', 'user', '用户信息', '0', '', '1', '{\"1\":[\"153\",\"152\",\"151\",\"154\",\"155\",\"158\",\"157\",\"156\",\"150\",\"149\",\"143\",\"142\",\"141\",\"144\",\"145\",\"148\",\"147\",\"146\",\"140\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\naccount:账号\r\nnickname:昵称\r\npromote_id:推广员编号\r\npromote_account:所属渠道\r\nbalance:余额\r\nlock_status|get_status_text*1:锁定状态\r\nlogin_time:登陆时间\r\nregister_time:注册时间\r\nlogin_ip:登陆IP\r\nregister_ip:注册IP', '10', '', '', '1463997820', '1464335255', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('12', 'UserPlay', '玩家信息', '0', '', '1', '{\"1\":[\"168\",\"167\",\"169\",\"170\",\"172\",\"171\",\"166\",\"165\",\"161\",\"160\",\"162\",\"163\",\"164\",\"159\"]}', '1:基础', '', '', '', '', '', 'id:编号', '10', '', '', '1463997856', '1463997966', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('13', 'UserLoginRecord', '用户登陆记录', '0', '', '1', '{\"1\":[\"179\",\"180\",\"181\",\"182\",\"178\",\"177\",\"174\",\"175\",\"176\",\"173\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nuser_account:用户名\r\nuser_nickname:昵称\r\ngame_id:游戏名称\r\nlogin_time:登陆时间', '10', '', '', '1463997904', '1464685303', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('14', 'spend', '消费记录', '0', '', '1', '{\"1\":[\"196\",\"195\",\"194\",\"197\",\"198\",\"201\",\"200\",\"199\",\"193\",\"192\",\"186\",\"185\",\"184\",\"187\",\"188\",\"190\",\"191\",\"189\",\"183\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_account:用户账号\r\ngame_name:游戏名称\r\npay_amount:充值金额\r\npromote_account:推广员账号\r\npromote_id:推广员id\r\npay_time|set_show_time:充值时间\r\npay_way:充值方式\r\npay_status:充值状态\r\nspend_ip:充值ip', '10', '', '', '1464012355', '1464830093', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('15', 'adv', '广告管理', '0', '', '1', '{\"1\":[\"209\",\"210\",\"211\",\"212\",\"208\",\"207\",\"203\",\"204\",\"205\",\"206\",\"202\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题\r\npos_id:广告位\r\ndata:图片\r\nurl:链接地址\r\nsort:排序\r\nstatus:状态\r\nstart_time:开始时间\r\nend_time:结束时间\r\ntarget:打开方式', '10', '', '', '1464083427', '1464099752', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('16', 'AdvPos', '广告位', '0', '', '1', '{\"1\":[\"220\",\"221\",\"222\",\"223\",\"219\",\"218\",\"214\",\"215\",\"216\",\"217\",\"213\"]}', '1:基础', '', '', '', '', '', 'id:编号', '10', '', '', '1464084894', '1464087047', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('17', 'deposit', '平台币充值', '0', '', '1', '{\"1\":[\"233\",\"232\",\"234\",\"235\",\"236\",\"231\",\"230\",\"226\",\"225\",\"227\",\"228\",\"229\",\"224\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_nickname:用户昵称\r\npromote_account:所属渠道\r\npay_amount:支付金额\r\ncreate_time:支付时间\r\npay_status:支付状态\r\npay_way:支付方式\r\npay_ip:支付IP', '10', '', '', '1464233084', '1464233284', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('18', 'provide', '平台币发放', '0', '', '1', '{\"1\":[\"247\",\"246\",\"248\",\"249\",\"251\",\"250\",\"245\",\"244\",\"239\",\"238\",\"240\",\"241\",\"243\",\"242\",\"237\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\ngame_name:游戏名称\r\nuser_nickname:用户昵称\r\namount:金额\r\nstatus:状态\r\nop_account:操作人\r\ncreate_time:时间', '10', '', '', '1464233863', '1464746533', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('19', 'BindSpend', '绑定平台币消费', '0', '', '1', '{\"1\":[\"263\",\"262\",\"261\",\"264\",\"265\",\"267\",\"266\",\"260\",\"259\",\"254\",\"253\",\"255\",\"256\",\"258\",\"257\",\"252\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_nickname:用户昵称\r\ngame_name:游戏\r\nprops_name:道具\r\npay_amount:金额\r\npay_time:时间\r\npay_status:状态\r\nspend_ip:支付IP', '10', '', '', '1464234376', '1464746845', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('20', 'GameSource', '游戏原包', '0', '', '1', '{\"1\":[\"275\",\"276\",\"277\",\"278\",\"274\",\"273\",\"269\",\"270\",\"271\",\"272\",\"268\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_id|get_game_name*id:游戏名称\r\nfile_name:文件名称\r\nfile_url:文件路径\r\nfile_size:文件大小\r\nop_account:操作人\r\ncreate_time|set_show_time:时间', '10', '', '', '1464235301', '1464940574', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('21', 'Apply', '游戏申请管理', '0', '', '1', '{\"1\":[\"287\",\"286\",\"288\",\"289\",\"290\",\"285\",\"284\",\"280\",\"281\",\"282\",\"283\",\"279\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_id|get_game_name:游戏名称\r\npromote_id|get_promote_name:推广员\r\nratio*10|ratio_stytl:分成比例\r\napply_time|set_show_time:申请时间\r\nstatus|get_info_status*5:申请状态\r\ndispose_id|get_admin_nickname:操作人\r\ndispose_time|set_show_time:操作时间\r\nid:操作:Apply/[EDIT]|编辑,Apply/package?ids=[id]|打包', '10', '', '', '1464356213', '1464926439', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('22', 'agent', '代充记录', '0', '', '1', '{\"1\":[\"302\",\"301\",\"300\",\"303\",\"304\",\"306\",\"305\",\"299\",\"298\",\"293\",\"292\",\"294\",\"295\",\"297\",\"296\",\"291\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\namount:充值金额\r\nreal_amount:实扣金额\r\nzhekou:折扣比例\r\npay_status:充值状态\r\nuser_account:充值账号\r\npromote_account:推广账号\r\npromote_id|get_belong_admin:所属专员', '10', '', '', '1464772695', '1464774710', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('24', 'settlement', '结算表', '0', '', '1', '', '1:基础', '', '', '', '', '', '', '10', '', '', '1464945956', '1464945956', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `sys_picture`
-- -----------------------------
DROP TABLE IF EXISTS `sys_picture`;
CREATE TABLE `sys_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_picture`
-- -----------------------------
INSERT INTO `sys_picture` VALUES ('1', '/Uploads/Picture/2016-05-24/57445cec1de81.jpg', '', '16e50e8f8d3728e911f187d551b2d488', '271bd8a88868a86c6ee0d0c886298a47bf0f7799', '1', '1464098028');
INSERT INTO `sys_picture` VALUES ('2', '/Uploads/Picture/2016-05-24/57445e152fba1.jpg', '', 'c66b0ee849105015303178c81693adb2', '10b54a50aa996c9098ce861e55cc182e6875fe6c', '1', '1464098325');
INSERT INTO `sys_picture` VALUES ('3', '/Uploads/Picture/2016-05-24/57445eae0f319.jpg', '', 'aa22cb1c4b20cb9bb9013c6aa82b898c', '6f743a519cc1cf7231c7f5598ea519ff5e6eb0c5', '1', '1464098477');

-- -----------------------------
-- Table structure for `sys_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_admin`;
CREATE TABLE `sys_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `sys_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_app`;
CREATE TABLE `sys_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `sys_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_member`;
CREATE TABLE `sys_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `sys_ucenter_member`
-- -----------------------------
INSERT INTO `sys_ucenter_member` VALUES ('1', 'admin', '43b54e1bfa09eb9819eb58fdeb34af69', 'admin@163.com', '', '1463641749', '2130706433', '1465029032', '2130706433', '1463641749', '1');
INSERT INTO `sys_ucenter_member` VALUES ('2', '111111', 'f714e22d958eb5fe42829a9c737ca0af', '1@qq.com', '', '1464665603', '2130706433', '0', '0', '1464665603', '1');

-- -----------------------------
-- Table structure for `sys_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_setting`;
CREATE TABLE `sys_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `sys_url`
-- -----------------------------
DROP TABLE IF EXISTS `sys_url`;
CREATE TABLE `sys_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `sys_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `sys_userdata`;
CREATE TABLE `sys_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_adv`
-- -----------------------------
DROP TABLE IF EXISTS `tab_adv`;
CREATE TABLE `tab_adv` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '广告名称',
  `pos_id` int(11) NOT NULL COMMENT '广告位置',
  `data` text NOT NULL COMMENT '图片地址',
  `click_count` int(11) NOT NULL COMMENT '点击量',
  `url` varchar(500) NOT NULL COMMENT '链接地址',
  `sort` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) unsigned DEFAULT '0' COMMENT '结束时间',
  `target` varchar(20) DEFAULT '_blank',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告表';

-- -----------------------------
-- Records of `tab_adv`
-- -----------------------------
INSERT INTO `tab_adv` VALUES ('5', '测试是数据', '3', '1', '0', 'http://www.baidu.com', '0', '1', '0', '1464169500', '1464155100', '_blank');
INSERT INTO `tab_adv` VALUES ('4', '基本配置', '2', '', '0', 'http://www.baidu.com', '0', '1', '0', '1970', '0', '_self');
INSERT INTO `tab_adv` VALUES ('3', '基本配置', '1', '2', '0', '111', '0', '1', '0', '1464183900', '1464271200', '_blank');
INSERT INTO `tab_adv` VALUES ('6', '测试轮播图', '1', '1', '0', 'http://www.baidu.com', '0', '1', '0', '1464710400', '1464882900', '_blank');

-- -----------------------------
-- Table structure for `tab_adv_pos`
-- -----------------------------
DROP TABLE IF EXISTS `tab_adv_pos`;
CREATE TABLE `tab_adv_pos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(50) NOT NULL,
  `title` char(80) NOT NULL DEFAULT '' COMMENT '广告位置名称',
  `module` varchar(100) NOT NULL COMMENT '所在模块 模块/控制器/方法',
  `type` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '广告位类型 \r\n1.单图\r\n2.多图\r\n3.文字链接\r\n4.代码',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `data` varchar(500) NOT NULL COMMENT '额外的数据',
  `width` char(20) NOT NULL DEFAULT '' COMMENT '广告位置宽度',
  `height` char(20) NOT NULL DEFAULT '' COMMENT '广告位置高度',
  `margin` varchar(50) NOT NULL COMMENT '边缘',
  `padding` varchar(50) NOT NULL COMMENT '留白',
  `theme` varchar(50) NOT NULL DEFAULT 'all' COMMENT '适用主题，默认为all，通用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告位置表';

-- -----------------------------
-- Records of `tab_adv_pos`
-- -----------------------------
INSERT INTO `tab_adv_pos` VALUES ('1', 'slider_media', '媒体首页轮播图', 'media', '2', '1', '', '1200px', '300px', '0', '0', 'all');
INSERT INTO `tab_adv_pos` VALUES ('2', 'index_top_media', '媒体首页顶部广告', 'media', '1', '1', '', '120px', '50px', '0', '0', 'all');
INSERT INTO `tab_adv_pos` VALUES ('3', 'slider_app', 'app首页轮播图', 'app', '2', '1', '', '120px', '30px', '0', '0', 'all');

-- -----------------------------
-- Table structure for `tab_agent`
-- -----------------------------
DROP TABLE IF EXISTS `tab_agent`;
CREATE TABLE `tab_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) NOT NULL COMMENT '支付订单号 ',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏ID',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏APPID',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `promote_id` int(11) DEFAULT '0' COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '玩家账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `amount` double(10,2) DEFAULT '0.00' COMMENT '支付金额',
  `real_amount` double(10,2) DEFAULT '0.00' COMMENT '实际金额',
  `pay_status` tinyint(2) DEFAULT '0' COMMENT '支付状态',
  `pay_type` tinyint(2) DEFAULT NULL COMMENT '类型',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  `zhekou` int(11) NOT NULL DEFAULT '0' COMMENT '折扣比例',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='代理充值记录';

-- -----------------------------
-- Records of `tab_agent`
-- -----------------------------
INSERT INTO `tab_agent` VALUES ('1', '', '', '', '', '', '0', '', '', '', '', '0.00', '0.00', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('2', '', 'AG_201606011002410aX9', '2', '', '', '62', '', '', 'tui', '', '0.00', '0.00', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('3', '', 'AG_20160601102644n2Yk', '2', '', '英雄我很忙', '62', 'tui001', '', 'tui001', '', '0.00', '0.00', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('5', '', 'AG_201606012115039vCx', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '', '', '', '100.00', '45.00', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('6', '', 'AG_20160601212326A2Cu', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '', '', '', '10.00', '4.50', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('7', '', 'AG_20160601212420nZS9', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '', 'wan001', '外婆家的西瓜皮', '10.00', '4.50', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('8', '', 'AG_20160601212453djD0', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '389', 'wan001', '外婆家的西瓜皮', '10.00', '4.50', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('9', '', 'AG_20160601212911hB4q', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '389', 'wan001', '外婆家的西瓜皮', '10.00', '4.50', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('10', '', 'AG_201606012138222vXP', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '389', 'wan001', '外婆家的西瓜皮', '100.00', '4.50', '0', '', '', '0');
INSERT INTO `tab_agent` VALUES ('11', '', '', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '0', '', '', 'wan001', '', '5.00', '4.50', '0', '0', '', '0');
INSERT INTO `tab_agent` VALUES ('12', '', 'AG_20160601214346OuWw', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '389', 'wan001', '外婆家的西瓜皮', '10.00', '4.50', '0', '0', '1464788626', '0');
INSERT INTO `tab_agent` VALUES ('13', '', 'AG_20160601214950SngI', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '389', 'wan001', '外婆家的西瓜皮', '100.00', '45.00', '0', '0', '1464788990', '0');
INSERT INTO `tab_agent` VALUES ('14', '', 'AG_20160601215147nYyp', '2', 'A6EE2E94AE603BD8C', '英雄我很忙', '62', 'tui001', '389', 'wan001', '外婆家的西瓜皮', '100.00', '45.00', '0', '0', '1464789107', '0');

-- -----------------------------
-- Table structure for `tab_apply`
-- -----------------------------
DROP TABLE IF EXISTS `tab_apply`;
CREATE TABLE `tab_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏ID',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广账号',
  `ratio` int(3) DEFAULT '0' COMMENT '分成比例',
  `apply_time` int(11) DEFAULT NULL COMMENT '申请时间',
  `status` tinyint(2) DEFAULT NULL COMMENT '审核状态',
  `enable_status` tinyint(2) DEFAULT NULL COMMENT '操作状态',
  `pack_url` varchar(255) DEFAULT NULL COMMENT '游戏包地址',
  `dow_url` varchar(255) DEFAULT NULL COMMENT '下载地址',
  `dispose_id` int(11) DEFAULT NULL COMMENT '操作人',
  `dispose_time` int(11) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=utf8 COMMENT='游戏申请表';

-- -----------------------------
-- Records of `tab_apply`
-- -----------------------------
INSERT INTO `tab_apply` VALUES ('93', '3', '', '81', 'asdasd', '0', '1464937245', '0', '1', '', '', '', '');
INSERT INTO `tab_apply` VALUES ('94', '1', '', '62', 'tui001', '0', '1464966217', '1', '1', 'D:/wamp/www/NewSY//Uploads/GamePack/game_package1-62.apk', '/index.php?s=/Down/down_file/game_id/1/promote_id/62', '1', '1464966419');
INSERT INTO `tab_apply` VALUES ('92', '3', '', '81', 'asdasd', '1', '1464936570', '1', '1', 'E:/wamp/www/newsy//Uploads/GamePack/game_package3-81.apk', '/index.php?s=/Down/down_file/game_id/3/promote_id/81', '1', '1464936560');

-- -----------------------------
-- Table structure for `tab_bind_spend`
-- -----------------------------
DROP TABLE IF EXISTS `tab_bind_spend`;
CREATE TABLE `tab_bind_spend` (
  `id` int(11) NOT NULL COMMENT '自增主键',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `user_account` varchar(30) NOT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) NOT NULL COMMENT '用户昵称',
  `game_id` int(11) NOT NULL COMMENT '游戏id',
  `game_appid` varchar(30) NOT NULL COMMENT '游戏appid',
  `game_name` varchar(30) NOT NULL COMMENT '游戏名称',
  `order_number` varchar(30) NOT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) NOT NULL COMMENT '商户订单号',
  `props_name` varchar(30) NOT NULL COMMENT '道具名称',
  `pay_amount` double(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `pay_time` int(11) NOT NULL COMMENT '支付时间',
  `pay_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `pay_game_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '游戏支付状态',
  `pay_way` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付方式',
  `pay_source` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付来源',
  `spend_ip` varchar(16) NOT NULL COMMENT '支付ip'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='绑定消费表';

-- -----------------------------
-- Records of `tab_bind_spend`
-- -----------------------------
INSERT INTO `tab_bind_spend` VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1.00', '1', '1', '1', '1', '1', '1');

-- -----------------------------
-- Table structure for `tab_deposit`
-- -----------------------------
DROP TABLE IF EXISTS `tab_deposit`;
CREATE TABLE `tab_deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '支付订单号',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广账号',
  `pay_amount` double(10,2) DEFAULT '0.00' COMMENT '充值金额',
  `pay_status` tinyint(2) DEFAULT '0' COMMENT '充值状态',
  `pay_way` tinyint(2) DEFAULT '0' COMMENT '支付方式',
  `pay_source` tinyint(2) DEFAULT '0' COMMENT '支付来源',
  `pay_ip` varchar(20) DEFAULT NULL COMMENT '充值IP',
  `create_time` int(11) DEFAULT NULL COMMENT '支付时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='平台币充值记录';

-- -----------------------------
-- Records of `tab_deposit`
-- -----------------------------
INSERT INTO `tab_deposit` VALUES ('1', '1', '1', '1', '1', '1', '62', 'tui001', '1.00', '1', '1', '1', '1', '1');
INSERT INTO `tab_deposit` VALUES ('28', '', 'PF_20160602181002Bdti', '389', 'wan001', '', '62', 'tui001', '10.00', '0', '0', '1', '127.0.0.1', '1464862202');

-- -----------------------------
-- Table structure for `tab_game`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game`;
CREATE TABLE `tab_game` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `sort` int(10) unsigned DEFAULT '1' COMMENT '排序',
  `short` varchar(20) DEFAULT NULL COMMENT '游戏简写',
  `game_type_id` int(10) DEFAULT NULL COMMENT '游戏类型id',
  `game_type_name` varchar(20) DEFAULT NULL COMMENT '游戏类型名称',
  `game_score` double(3,0) DEFAULT NULL COMMENT '游戏评分',
  `features` varchar(50) DEFAULT NULL COMMENT '游戏特征',
  `recommend_level` double(3,0) DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL COMMENT '版本号',
  `game_size` varchar(10) DEFAULT '0' COMMENT '游戏大小',
  `icon` int(11) DEFAULT NULL COMMENT '游戏图标',
  `cover` int(11) DEFAULT NULL COMMENT '游戏封面',
  `screenshot` varchar(255) DEFAULT NULL COMMENT '游戏截图',
  `introduction` varchar(300) DEFAULT NULL COMMENT '游戏简介',
  `and_dow_address` varchar(255) DEFAULT NULL COMMENT '安卓游戏下载地址',
  `ios_dow_address` varchar(255) DEFAULT NULL COMMENT 'ios游戏下载地址',
  `game_address` varchar(255) DEFAULT NULL COMMENT '外部链接游戏地址',
  `dow_num` int(10) DEFAULT '0' COMMENT '游戏下载数量',
  `game_status` tinyint(2) DEFAULT NULL COMMENT '游戏状态(0:关闭,1:开启)',
  `recommend_status` tinyint(2) DEFAULT '1' COMMENT '推荐状态(0:否,1是)',
  `pay_status` tinyint(2) DEFAULT '1' COMMENT '充值状态(0:关闭,1:开启)',
  `dow_status` tinyint(2) DEFAULT '1' COMMENT '下载状态(0:关闭,1:开启)',
  `developers` varchar(30) DEFAULT NULL COMMENT '开发商',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `discount` int(3) DEFAULT NULL COMMENT '折扣',
  `language` varchar(10) DEFAULT NULL COMMENT '语言',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏appid',
  `game_coin_name` varchar(10) DEFAULT NULL COMMENT '游戏币名称',
  `game_coin_ration` varchar(10) DEFAULT NULL COMMENT '游戏币比例',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='游戏表';

-- -----------------------------
-- Records of `tab_game`
-- -----------------------------
INSERT INTO `tab_game` VALUES ('1', '测试游戏', '0', '', '3', '网络游戏 ', '0', '', '0', '1.0.2', '0MB', '0', '0', '', '', './Uploads/SourcePack/20160604160319_912.apk', '', '', '0', '1', '1', '1', '1', '', '1463984609', '0', '', 'A6EE2E94AE603BD8C', '', '');
INSERT INTO `tab_game` VALUES ('2', '英雄我很忙', '0', '', '3', '网络游戏 ', '0', '', '0', '1.0.2', '0MB', '0', '0', '', '', './Uploads/SourcePack/20160603203407_921.rar', '', '', '0', '1', '1', '1', '1', '', '1463984609', '0', '', 'A6EE2E94AE603BD8C', '', '');

-- -----------------------------
-- Table structure for `tab_game_set`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game_set`;
CREATE TABLE `tab_game_set` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) NOT NULL COMMENT '游戏ID',
  `login_notify_url` varchar(255) DEFAULT NULL COMMENT '游戏登陆通知地址',
  `pay_notify_url` varchar(255) DEFAULT NULL COMMENT '游戏支付通知地址',
  `game_role_url` varchar(255) DEFAULT NULL COMMENT '游戏角色获取地址',
  `game_gift_url` varchar(255) DEFAULT NULL COMMENT '游戏礼包领取地址',
  `game_key` varchar(32) DEFAULT NULL COMMENT '游戏key',
  `access_key` varchar(32) DEFAULT NULL COMMENT '访问秘钥',
  `agent_id` varchar(32) DEFAULT NULL COMMENT '代理id(合作方标示)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='游戏设置表（游戏对接时调用）';

-- -----------------------------
-- Records of `tab_game_set`
-- -----------------------------
INSERT INTO `tab_game_set` VALUES ('3', '1', '', '', '', '', '', '', '');
INSERT INTO `tab_game_set` VALUES ('4', '4', '', '', '', '', '', '', '');
INSERT INTO `tab_game_set` VALUES ('5', '2', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `tab_game_source`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game_source`;
CREATE TABLE `tab_game_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `file_id` int(11) DEFAULT NULL COMMENT '文件id',
  `file_name` varchar(30) DEFAULT NULL COMMENT '文件名称',
  `file_url` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `file_size` varchar(30) NOT NULL COMMENT '文件大小',
  `file_type` tinyint(2) DEFAULT NULL COMMENT '原包类型',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(30) DEFAULT NULL COMMENT '操作人名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='游戏原包';

-- -----------------------------
-- Records of `tab_game_source`
-- -----------------------------
INSERT INTO `tab_game_source` VALUES ('29', '1', '测试游戏', '0', '20160604160319_912.apk', './Uploads/SourcePack/20160604160319_912.apk', '1.14MB', '1', '1', 'admin', '', '1465027407');
INSERT INTO `tab_game_source` VALUES ('30', '2', '英雄我很忙', '0', '20160603203407_921.rar', './Uploads/SourcePack/20160603203407_921.rar', '658MB', '1', '1', 'admin', '1111', '1464957275');

-- -----------------------------
-- Table structure for `tab_game_type`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game_type`;
CREATE TABLE `tab_game_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type_name` varchar(20) DEFAULT NULL COMMENT '游戏类型名称',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态(-1:删除,1:正常)',
  `status_show` tinyint(2) DEFAULT '1' COMMENT '显示状态(0:不显示,1:显示)',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_nickname` varchar(30) DEFAULT NULL COMMENT '操作人昵称',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='游戏类型表';

-- -----------------------------
-- Records of `tab_game_type`
-- -----------------------------
INSERT INTO `tab_game_type` VALUES ('2', '休闲益智', '1', '1', '1', '', '1463974585');
INSERT INTO `tab_game_type` VALUES ('3', '网络游戏', '1', '1', '1', 'admin', '1463974875');

-- -----------------------------
-- Table structure for `tab_gift_record`
-- -----------------------------
DROP TABLE IF EXISTS `tab_gift_record`;
CREATE TABLE `tab_gift_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `gift_id` int(11) DEFAULT NULL COMMENT '礼包id',
  `gift_name` varchar(30) DEFAULT NULL COMMENT '礼包名称',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态(0:未使用,1:已使用)',
  `novice` varchar(30) DEFAULT NULL COMMENT '激活码',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COMMENT='礼包领取记录';

-- -----------------------------
-- Records of `tab_gift_record`
-- -----------------------------
INSERT INTO `tab_gift_record` VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- -----------------------------
-- Table structure for `tab_giftbag`
-- -----------------------------
DROP TABLE IF EXISTS `tab_giftbag`;
CREATE TABLE `tab_giftbag` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` int(30) DEFAULT NULL COMMENT '区服名称',
  `giftbag_name` varchar(30) DEFAULT NULL COMMENT '礼包名称',
  `giftbag_type` tinyint(2) DEFAULT NULL COMMENT '礼包类型',
  `level` int(3) DEFAULT NULL COMMENT '领取等级',
  `sort` int(10) DEFAULT '0' COMMENT '排序',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态',
  `call_api` tinyint(2) DEFAULT '0' COMMENT '调用接口',
  `tong_server` tinyint(2) DEFAULT '0' COMMENT '是否通服',
  `novice` varchar(3000) DEFAULT NULL COMMENT '激活码',
  `digest` varchar(300) DEFAULT NULL COMMENT '摘要',
  `desribe` varchar(300) DEFAULT NULL COMMENT '描述',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='礼包管理';

-- -----------------------------
-- Records of `tab_giftbag`
-- -----------------------------
INSERT INTO `tab_giftbag` VALUES ('10', '2', '英雄我很忙', '2', '123', '英雄我很忙-新手礼包', '1', '0', '0', '1', '0', '0', '123', '132', '123', '1462768800', '1462949400', '1463987515');

-- -----------------------------
-- Table structure for `tab_mend`
-- -----------------------------
DROP TABLE IF EXISTS `tab_mend`;
CREATE TABLE `tab_mend` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `promote_id_to` int(11) DEFAULT NULL COMMENT '修改后推广员id',
  `promote_account_to` varchar(30) DEFAULT NULL COMMENT '修改后推广员账号',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(30) DEFAULT NULL COMMENT '操作人账号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tab_mend`
-- -----------------------------
INSERT INTO `tab_mend` VALUES ('1', '389', 'wan001', '外婆家的西瓜皮', '0', '自然注册', '62', 'tui001', '', '1464331606', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('2', '389', 'wan001', '外婆家的西瓜皮', '62', 'tui001', '63', 'tui002', '1111', '1464331719', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('3', '389', 'wan001', '外婆家的西瓜皮', '66', 'tui001-02', '63', 'tui002', '', '1464761715', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('4', '389', 'wan001', '外婆家的西瓜皮', '63', 'tui002', '68', 'tui001-04', '', '1464761719', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('5', '389', 'wan001', '外婆家的西瓜皮', '68', 'tui001-04', '65', 'tui001-01', '', '1464761721', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('6', '389', 'wan001', '外婆家的西瓜皮', '65', 'tui001-01', '62', 'tui001', '', '1464761853', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('7', '389', 'wan001', '外婆家的西瓜皮', '62', 'tui001', '63', 'tui002', '', '1464761886', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('8', '389', 'wan001', '外婆家的西瓜皮', '63', 'tui002', '62', 'tui001', '', '1464762021', '1', 'admin');
INSERT INTO `tab_mend` VALUES ('9', '390', 'wan002', 'wan002', '0', '', '62', 'tui001', '', '1464915544', '1', 'admin');

-- -----------------------------
-- Table structure for `tab_promote`
-- -----------------------------
DROP TABLE IF EXISTS `tab_promote`;
CREATE TABLE `tab_promote` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `account` varchar(30) DEFAULT NULL COMMENT '账号',
  `password` varchar(32) DEFAULT NULL COMMENT '密码',
  `second_pwd` varchar(32) DEFAULT NULL COMMENT '二级密码',
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `mobile_phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `real_name` varchar(10) DEFAULT NULL COMMENT '真实姓名',
  `bank_name` varchar(50) DEFAULT NULL COMMENT '银行',
  `bank_card` varchar(20) DEFAULT NULL COMMENT '银行卡',
  `money` double(10,2) DEFAULT '0.00' COMMENT '金额',
  `total_money` double(10,2) DEFAULT '0.00' COMMENT '总金额',
  `balance_coin` double(10,2) DEFAULT '0.00' COMMENT '平台币',
  `promote_type` int(2) DEFAULT '1' COMMENT '推广员类型',
  `status` int(11) DEFAULT '1' COMMENT '状态',
  `parent_id` int(11) DEFAULT '0' COMMENT '父类ID',
  `referee_id` int(11) DEFAULT '0' COMMENT '推荐人ID',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `admin_id` int(11) NOT NULL COMMENT '管理员id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COMMENT='推广员';

-- -----------------------------
-- Records of `tab_promote`
-- -----------------------------
INSERT INTO `tab_promote` VALUES ('62', 'tui001', '446a965523ea4a527abbaa3b344d2bed', '', '璞玉', '12598564853', 'test0@163.com', '邓超', '北京政府银行0', '6265658523223', '0.00', '0.00', '0.00', '1', '1', '0', '0', '1463992547', '1');
INSERT INTO `tab_promote` VALUES ('63', 'tui002', '43b54e1bfa09eb9819eb58fdeb34af69', '', '', '12598564853', '', '邓超1', '北京政府银行', '6265658523223', '0.00', '0.00', '0.00', '1', '1', '0', '0', '1463992547', '1');
INSERT INTO `tab_promote` VALUES ('65', 'tui001-01', '', '', 'tui001-01', '问0', '请问0', '问0', '问0', '问0', '0.00', '0.00', '0.00', '1', '1', '62', '0', '1464574684', '1');
INSERT INTO `tab_promote` VALUES ('66', 'tui001-02', '43b54e1bfa09eb9819eb58fdeb34af69', '', 'tui001-02', '123', '123@163.com', '123', '123', '132', '0.00', '0.00', '0.00', '1', '1', '62', '0', '1464574967', '1');
INSERT INTO `tab_promote` VALUES ('67', 'tui001-03', '43b54e1bfa09eb9819eb58fdeb34af69', '', 'tui001-03', '123', '123', '123', '123', '123', '0.00', '0.00', '0.00', '1', '0', '0', '0', '1464575031', '1');
INSERT INTO `tab_promote` VALUES ('68', 'tui001-04', '43b54e1bfa09eb9819eb58fdeb34af69', '', 'tui001-04', 'as fd', 'asdf ', 'asdf ', 'sad f', 'adsf ', '0.00', '0.00', '0.00', '1', '1', '62', '0', '1464575623', '0');

-- -----------------------------
-- Table structure for `tab_provide`
-- -----------------------------
DROP TABLE IF EXISTS `tab_provide`;
CREATE TABLE `tab_provide` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '商户订单号',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `amount` double(10,2) DEFAULT NULL COMMENT '充值金额',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(30) DEFAULT NULL COMMENT '操作人账号',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='平台币发发放记录';

-- -----------------------------
-- Records of `tab_provide`
-- -----------------------------
INSERT INTO `tab_provide` VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1.00', '1', '1', '1', '1', '1');

-- -----------------------------
-- Table structure for `tab_server`
-- -----------------------------
DROP TABLE IF EXISTS `tab_server`;
CREATE TABLE `tab_server` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `game_id` int(11) NOT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `server_num` int(11) DEFAULT NULL COMMENT '对接区服id',
  `recommend_status` tinyint(2) DEFAULT '1' COMMENT '推荐状态(0:否,1:是)',
  `show_status` tinyint(2) DEFAULT '1' COMMENT '显示状态(0:否,1:是)',
  `stop_status` tinyint(2) DEFAULT '0' COMMENT '是否停服(0:否,1:是)',
  `server_status` tinyint(2) DEFAULT '0' COMMENT '区服状态(0:正常,1拥挤,2爆满)',
  `icon` int(11) DEFAULT NULL COMMENT '区服图标',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `desride` varchar(300) DEFAULT NULL COMMENT '描述',
  `prompt` varchar(300) DEFAULT NULL COMMENT '停服提示',
  `parent_id` int(11) DEFAULT NULL COMMENT '父类id',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='游戏区服表';

-- -----------------------------
-- Records of `tab_server`
-- -----------------------------
INSERT INTO `tab_server` VALUES ('2', '2', '英雄我很忙', '双线一区', '1', '1', '1', '0', '1', '', '1464676197', '1231', '123', '0', '1463985314');
INSERT INTO `tab_server` VALUES ('3', '2', '英雄我很忙', '双线二区', '2', '1', '1', '0', '1', '', '1464676197', '1231', '123', '0', '1463985314');

-- -----------------------------
-- Table structure for `tab_settlement`
-- -----------------------------
DROP TABLE IF EXISTS `tab_settlement`;
CREATE TABLE `tab_settlement` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `game_id` varchar(32) DEFAULT NULL COMMENT '游戏ID',
  `spend_time` int(11) DEFAULT NULL COMMENT '消费时间',
  `reg_num` int(10) DEFAULT '0' COMMENT '注册人数',
  `spend_num` int(10) DEFAULT '0' COMMENT '消费人数',
  `money` double(10,2) DEFAULT '0.00' COMMENT '金额',
  `real_money` double(10,2) DEFAULT '0.00' COMMENT '实际金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '结算状态',
  `type` tinyint(2) DEFAULT '0' COMMENT '类型',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tab_settlement`
-- -----------------------------
INSERT INTO `tab_settlement` VALUES ('8', '62', '1', '1464796800', '0', '0', '12.00', '0.00', '1', '0');
INSERT INTO `tab_settlement` VALUES ('9', '62', '2', '1464796800', '0', '0', '12.00', '0.00', '1', '0');

-- -----------------------------
-- Table structure for `tab_spend`
-- -----------------------------
DROP TABLE IF EXISTS `tab_spend`;
CREATE TABLE `tab_spend` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) NOT NULL COMMENT ' 用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏appid',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '支付订单号',
  `props_name` varchar(30) DEFAULT NULL COMMENT '道具名称',
  `pay_amount` double(10,2) DEFAULT NULL COMMENT '支付金额',
  `pay_time` int(11) DEFAULT NULL COMMENT '支付时间',
  `pay_status` tinyint(2) DEFAULT NULL COMMENT '支付状态',
  `pay_game_status` tinyint(2) DEFAULT NULL COMMENT '游戏支付状态',
  `pay_way` tinyint(2) DEFAULT NULL COMMENT '支付方式',
  `spend_ip` varchar(20) DEFAULT NULL COMMENT '支付IP',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tab_spend`
-- -----------------------------
INSERT INTO `tab_spend` VALUES ('1', '389', 'wan001', '外婆家的西瓜皮', '1', 'A6EE2E94AE603BD8C', '测试游戏', '2', '12', '62', 'tui001', '02262545091554', '562345215544555', '12', '12.00', '1464800401', '1', '1', '0', '127.0.0.1');
INSERT INTO `tab_spend` VALUES ('2', '389', 'wan001', '外婆家的西瓜皮', '2', 'A6EE2E94AE603BD8C', '测试游戏', '2', '12', '62', 'tui001', '02262545091554', '562345215544555', '12', '12.00', '1464800400', '1', '1', '1', '127.0.0.1');

-- -----------------------------
-- Table structure for `tab_tool`
-- -----------------------------
DROP TABLE IF EXISTS `tab_tool`;
CREATE TABLE `tab_tool` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `name` varchar(30) DEFAULT NULL COMMENT '标识',
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `config` text COMMENT '配置文件内容',
  `template` text COMMENT '模板内容',
  `type` tinyint(3) DEFAULT NULL COMMENT '类型',
  `status` tinyint(3) DEFAULT NULL COMMENT '状态',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='扩展工具表';

-- -----------------------------
-- Records of `tab_tool`
-- -----------------------------
INSERT INTO `tab_tool` VALUES ('1', 'sms_set', '短信设置', '{\"smtp\":\"000\",\"smtp_port\":\"20\",\"smtp_account\":\"test\",\"smtp_password\":\"123456\",\"smtp_test\":\"test@163.com\"}', '11100', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('2', 'oss_storage', 'OSS存储', '{\"bucket\":\"111\",\"accesskeyid\":\"11\",\"accesskeysecr\":\"11\",\"domain\":\"11\"}', '', '1', '0', '1464164373');
INSERT INTO `tab_tool` VALUES ('3', 'qiniu_storage', '七牛存储', '{\"bucket\":\"22\",\"accesskeyid\":\"222\",\"accesskeysecr\":\"22\",\"domain\":\"22\"}', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('4', 'alipay_pay', '支付宝设置', '', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('5', 'weixin_pay', '微信设置', '', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('6', 'email_set', '邮件设置', '', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('7', 'qq_login', 'QQ登陆设置', '', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('8', 'wx_login', '微信登陆设置', '', '', '1', '1', '1464164373');

-- -----------------------------
-- Table structure for `tab_user`
-- -----------------------------
DROP TABLE IF EXISTS `tab_user`;
CREATE TABLE `tab_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `account` varchar(30) DEFAULT NULL COMMENT '登陆账号',
  `password` varchar(32) DEFAULT NULL COMMENT '登陆密码',
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号码',
  `real_name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `idcard` varchar(20) DEFAULT NULL COMMENT '身份证',
  `vip_level` tinyint(2) DEFAULT '0' COMMENT 'vip等级',
  `cumulative` double(10,2) DEFAULT '0.00' COMMENT '累计充值',
  `balance` double(10,2) DEFAULT '0.00' COMMENT '余额',
  `anti_addiction` tinyint(2) DEFAULT '0' COMMENT '防沉迷',
  `lock_status` tinyint(2) DEFAULT '1' COMMENT '锁定状态',
  `register_way` tinyint(2) DEFAULT '0' COMMENT '注册方式',
  `register_time` int(11) DEFAULT NULL COMMENT '注册时间',
  `login_time` int(11) DEFAULT NULL COMMENT '登陆时间',
  `register_ip` varchar(16) NOT NULL COMMENT '注册ip',
  `login_ip` varchar(16) NOT NULL COMMENT '登陆ip',
  `promote_id` int(11) NOT NULL DEFAULT '0' COMMENT '推广id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=391 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `tab_user`
-- -----------------------------
INSERT INTO `tab_user` VALUES ('389', 'wan001', '43b54e1bfa09eb9819eb58fdeb34af69', '外婆家的西瓜皮', 'wan001@163.com', '15852365987', '吴京', '401232198005217412', '0', '0.00', '0.00', '0', '1', '0', '1464332222', '1464849919', '192.168.2.207', '127.0.0.1', '62', 'tui001');
INSERT INTO `tab_user` VALUES ('390', 'wan002', '43b54e1bfa09eb9819eb58fdeb34af69', 'wan002', '', '', '', '', '0', '0.00', '0.00', '0', '1', '0', '1464848728', '', '', '', '62', 'tui001');

-- -----------------------------
-- Table structure for `tab_user_login_record`
-- -----------------------------
DROP TABLE IF EXISTS `tab_user_login_record`;
CREATE TABLE `tab_user_login_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT ' 游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `login_time` int(11) DEFAULT NULL COMMENT '登陆时间',
  `login_ip` varchar(20) DEFAULT NULL COMMENT '登陆ip',
  `type` tinyint(2) DEFAULT '1' COMMENT '类型(1:游戏登陆,2:PC登陆)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tab_user_login_record`
-- -----------------------------
INSERT INTO `tab_user_login_record` VALUES ('2', '2', '2', '2', '2', '389', 'wan001', '2', '1464676197', '2', '2');

-- -----------------------------
-- Table structure for `tab_user_play`
-- -----------------------------
DROP TABLE IF EXISTS `tab_user_play`;
CREATE TABLE `tab_user_play` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `game_id` int(11) NOT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏appid',
  `server_id` int(11) NOT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `role_id` int(11) DEFAULT '0' COMMENT '角色',
  `bind_balance` double DEFAULT '0' COMMENT '绑定平台币',
  `role_name` varchar(20) DEFAULT NULL COMMENT '角色名称',
  `role_level` int(3) DEFAULT '0' COMMENT '等级',
  `promote_id` int(11) DEFAULT '0' COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 COMMENT='玩家表';

-- -----------------------------
-- Records of `tab_user_play`
-- -----------------------------
INSERT INTO `tab_user_play` VALUES ('280', '389', 'wan001', '外婆家的西瓜皮', '2', '英雄我很忙', 'A6EE2E94AE603BD8C', '0', '', '0', '0', '', '0', '62', 'tui001');

-- -----------------------------
-- Table structure for `tab_withdraw`
-- -----------------------------
DROP TABLE IF EXISTS `tab_withdraw`;
CREATE TABLE `tab_withdraw` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `amount` double(10,2) DEFAULT '0.00' COMMENT '金额',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人ID',
  `op_account` varchar(20) DEFAULT NULL COMMENT '操作人',
  `create_time` int(11) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='结算表';

-- -----------------------------
-- Records of `tab_withdraw`
-- -----------------------------
INSERT INTO `tab_withdraw` VALUES ('4', '3', '10.00', '', '1', 'admin', '1459353723');
INSERT INTO `tab_withdraw` VALUES ('5', '81', '1111.00', '', '1', 'admin', '1465007754');
